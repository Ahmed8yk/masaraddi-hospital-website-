import React from 'react';
import { Phone, MapPin, Mail, MessageSquare, Star, Activity, Heart } from 'lucide-react';
import { hospitalConfig } from '../config/hospitalConfig';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-[#080E1A] text-white pt-20 pb-24 md:pb-14 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 lg:gap-8 pb-14 border-b border-slate-800/80">
          
          {/* Col 1: Hospital Branding & Summary */}
          <div className="lg:col-span-4 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-sky-500 to-blue-600 flex items-center justify-center text-white shadow-lg shadow-sky-500/20">
                <Activity className="w-6 h-6 text-white" />
              </div>
              <div>
                <span className="font-extrabold text-lg text-white font-outfit uppercase tracking-tight block">
                  Masaraddi
                </span>
                <span className="text-sky-400 text-xs font-bold uppercase tracking-wider block">
                  Neuro Care Center
                </span>
              </div>
            </div>

            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
              Dedicated neurological clinical care, outpatient evaluations, and inpatient monitoring on Station Road in Bagalkot, Karnataka.
            </p>

            {/* Google Rating Badge in Footer */}
            <div className="inline-flex items-center gap-2 px-3.5 py-2 rounded-2xl bg-slate-900 border border-slate-800 text-xs text-white">
              <div className="flex items-center text-amber-400">
                <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                <span className="ml-1 font-bold">{hospitalConfig.rating}</span>
              </div>
              <span className="text-slate-600">·</span>
              <span className="text-slate-300">{hospitalConfig.reviewCount} Google Reviews</span>
            </div>
          </div>

          {/* Col 2: Quick Links */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="text-xs font-bold text-sky-400 uppercase tracking-wider">
              Quick Links
            </h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>
                <a href="#home" className="hover:text-white transition-colors">Home</a>
              </li>
              <li>
                <a href="#about" className="hover:text-white transition-colors">About Hospital</a>
              </li>
              <li>
                <a href="#services" className="hover:text-white transition-colors">Neuro Services</a>
              </li>
              <li>
                <a href="#doctors" className="hover:text-white transition-colors">Doctors & Staff</a>
              </li>
              <li>
                <a href="#facilities" className="hover:text-white transition-colors">Hospital Facilities</a>
              </li>
              <li>
                <a href="#gallery" className="hover:text-white transition-colors">Photo Gallery</a>
              </li>
              <li>
                <a href="#reviews" className="hover:text-white transition-colors">Patient Reviews</a>
              </li>
              <li>
                <a href="#faqs" className="hover:text-white transition-colors">FAQs</a>
              </li>
            </ul>
          </div>

          {/* Col 3: Specialties */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-xs font-bold text-sky-400 uppercase tracking-wider">
              Specialized Care
            </h4>
            <ul className="space-y-1.5 text-xs text-slate-400">
              <li>• Epilepsy & Seizure Management</li>
              <li>• Stroke Assessment & Neuro-Rehab</li>
              <li>• Headache & Chronic Migraine Clinic</li>
              <li>• Spine, Sciatica & Peripheral Nerve Care</li>
              <li>• Inpatient Monitoring & Neuro Diagnostics</li>
              <li>• Parkinson's & Movement Disorder Support</li>
            </ul>
          </div>

          {/* Col 4: Contact & Hours */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-xs font-bold text-sky-400 uppercase tracking-wider">
              Hospital Desk
            </h4>
            <div className="space-y-2.5 text-xs text-slate-300">
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
                <span>Station Road, Bagalkot, Karnataka - 587101</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-sky-400 shrink-0" />
                <a href={`tel:${hospitalConfig.contact.phone}`} className="hover:text-sky-300 font-bold">
                  {hospitalConfig.contact.phoneDisplay}
                </a>
              </div>
              <div className="flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-emerald-400 shrink-0" />
                <a
                  href={`https://wa.me/${hospitalConfig.contact.whatsappNumber}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-emerald-300"
                >
                  WhatsApp Consultation Desk
                </a>
              </div>
            </div>

            {/* Timings */}
            <div className="pt-2 text-[11px] text-slate-400 border-t border-slate-800 space-y-0.5">
              <p>OPD Hours: {hospitalConfig.contact.timings.opd}</p>
              <p>Inpatient & Emergency: {hospitalConfig.contact.timings.emergency}</p>
            </div>
          </div>

        </div>

        {/* Medical & Legal Disclaimer */}
        <div className="pt-8 pb-4 text-center space-y-2">
          <p className="text-[11px] text-slate-400 max-w-3xl mx-auto leading-relaxed">
            <strong>Medical Disclaimer:</strong> The information published on this website is for informational purposes and patient assistance. It does not replace professional medical diagnosis, doctor consultation, or specialized treatment. Always consult qualified doctors at Masaraddi Neuro Care Center for medical advice.
          </p>
          
          <div className="flex flex-wrap items-center justify-center gap-2 text-xs text-slate-400 pt-2">
            <span>© {new Date().getFullYear()} Masaraddi Neuro Care Center, Bagalkot. All rights reserved.</span>
            <span>·</span>
            <span>Station Road, Bagalkot, Karnataka</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
