import React from 'react';
import { Star, Quote, CheckCircle2, MessageSquare, ExternalLink } from 'lucide-react';
import { hospitalConfig } from '../config/hospitalConfig';

export const ReviewsSection: React.FC = () => {
  const reviews = hospitalConfig.reviews;

  return (
    <section id="reviews" className="py-24 bg-[#F8FAFC] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-50 border border-amber-200 text-amber-900 text-xs font-bold tracking-wide uppercase shadow-sm">
            <Star className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
            <span>Google Verified Patient Testimonials</span>
          </div>
          
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#0B132B] tracking-tight font-outfit">
            Trusted by Patients Across North Karnataka
          </h2>
          
          <p className="text-base sm:text-lg text-slate-600 leading-relaxed">
            Read authentic feedback from patients and families who received neurological consultation, stroke recovery, and clinical care at our Bagalkot center.
          </p>
        </div>

        {/* Rating Trust Overview Card */}
        <div className="mt-12 bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-[0_10px_30px_rgba(0,0,0,0.03)] max-w-3xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex flex-col items-center justify-center shrink-0">
              <span className="text-2xl font-black text-amber-600 font-outfit leading-none">{hospitalConfig.rating}</span>
              <div className="flex items-center text-amber-500 mt-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-2.5 h-2.5 fill-amber-500 text-amber-500" />
                ))}
              </div>
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold text-[#0B132B] font-outfit">
                Google Rating & Verified Patient Sentiment
              </h3>
              <p className="text-xs sm:text-sm text-slate-500">
                Based on {hospitalConfig.reviewCount} authentic Google ratings & reviews on Station Road, Bagalkot.
              </p>
            </div>
          </div>

          <div className="shrink-0 flex items-center gap-2">
            <span className="text-xs font-bold text-slate-700 bg-slate-100 px-3 py-1.5 rounded-xl">
              100% Real Reviews
            </span>
          </div>
        </div>

        {/* Reviews Grid */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {reviews.map((rev) => (
            <div
              key={rev.id}
              className="bg-white rounded-3xl p-7 border border-slate-200/80 shadow-[0_4px_20px_rgba(0,0,0,0.02)] hover:shadow-lg hover:border-sky-200 transition-all duration-300 flex flex-col justify-between"
            >
              <div className="space-y-4">
                {/* Rating Stars & Quote Icon */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1 text-amber-500">
                    {[...Array(rev.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-amber-500 text-amber-500" />
                    ))}
                  </div>
                  <Quote className="w-6 h-6 text-slate-200" />
                </div>

                {/* Review Text */}
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed italic">
                  "{rev.text}"
                </p>

                {/* Treatment Category Tag */}
                {rev.treatmentCategory && (
                  <div className="pt-1">
                    <span className="text-[11px] font-semibold text-sky-700 bg-sky-50 px-2.5 py-0.5 rounded-full border border-sky-100">
                      {rev.treatmentCategory}
                    </span>
                  </div>
                )}
              </div>

              {/* Author & Location */}
              <div className="pt-4 mt-6 border-t border-slate-100 flex items-center justify-between text-xs">
                <div>
                  <div className="font-bold text-[#0B132B] flex items-center gap-1">
                    <span>{rev.author}</span>
                    <CheckCircle2 className="w-3.5 h-3.5 text-sky-600" />
                  </div>
                  <span className="text-slate-400">{rev.location}</span>
                </div>
                <span className="text-slate-400 font-medium">{rev.date}</span>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
