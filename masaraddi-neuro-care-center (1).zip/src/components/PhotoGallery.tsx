import React, { useState } from 'react';
import { Camera, Eye, X, ChevronLeft, ChevronRight, MapPin, Sparkles } from 'lucide-react';
import { hospitalConfig } from '../config/hospitalConfig';

export const PhotoGallery: React.FC = () => {
  const [selectedImageIndex, setSelectedImageIndex] = useState<number | null>(null);
  const [activeFilter, setActiveFilter] = useState<string>('all');

  const photos = hospitalConfig.gallery;

  const filters = [
    { id: 'all', label: 'All Photos' },
    { id: 'exterior', label: 'Exterior' },
    { id: 'consultation', label: 'Doctor Consultation' },
    { id: 'patient_care', label: 'Inpatient Wards' },
    { id: 'facilities', label: 'Facilities' },
    { id: 'diagnostics', label: 'Diagnostics' },
  ];

  const filteredPhotos = activeFilter === 'all'
    ? photos
    : photos.filter(p => p.category === activeFilter);

  const openLightbox = (index: number) => {
    setSelectedImageIndex(index);
  };

  const closeLightbox = () => {
    setSelectedImageIndex(null);
  };

  const nextPhoto = () => {
    if (selectedImageIndex === null) return;
    setSelectedImageIndex((selectedImageIndex + 1) % filteredPhotos.length);
  };

  const prevPhoto = () => {
    if (selectedImageIndex === null) return;
    setSelectedImageIndex(
      (selectedImageIndex - 1 + filteredPhotos.length) % filteredPhotos.length
    );
  };

  return (
    <section id="gallery" className="py-24 bg-[#080E1A] text-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-slate-900 border border-sky-500/30 text-sky-400 text-xs font-bold tracking-wide uppercase shadow-sm">
            <Camera className="w-3.5 h-3.5 text-sky-400" />
            <span>Real Hospital Campus</span>
          </div>
          
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight font-outfit">
            Explore Masaraddi Neuro Care Center
          </h2>
          
          <p className="text-base sm:text-lg text-slate-300 leading-relaxed">
            Take a visual walkthrough of our specialized neurology hospital, consultation chambers, patient wards, and reception on Station Road, Bagalkot.
          </p>
        </div>

        {/* Gallery Filter Tabs */}
        <div className="mt-10 flex flex-wrap items-center justify-center gap-2">
          {filters.map((f) => (
            <button
              key={f.id}
              onClick={() => setActiveFilter(f.id)}
              className={`px-4 py-2 rounded-2xl text-xs sm:text-sm font-bold transition-all duration-200 ${
                activeFilter === f.id
                  ? 'bg-gradient-to-r from-sky-500 to-blue-600 text-white shadow-lg shadow-sky-600/30'
                  : 'bg-slate-900/90 text-slate-300 hover:text-white hover:bg-slate-800 border border-slate-800'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>

        {/* Masonry / Grid Gallery */}
        <div className="mt-12 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredPhotos.map((photo, index) => (
            <div
              key={photo.id}
              onClick={() => openLightbox(index)}
              className="group relative rounded-3xl overflow-hidden bg-slate-900 border border-slate-800 cursor-pointer shadow-lg hover:border-sky-500/40 hover:shadow-sky-500/10 transition-all duration-300 aspect-4/3"
            >
              <img
                src={photo.image}
                alt={photo.altText || photo.title}
                className="w-full h-full object-cover group-hover:scale-108 transition-transform duration-500"
                loading="lazy"
              />
              
              {/* Subtle Dark Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#080E1A] via-black/20 to-transparent opacity-80 group-hover:opacity-90 transition-opacity" />

              {/* Tag & View Badge */}
              <div className="absolute top-3.5 left-3.5 right-3.5 flex items-center justify-between">
                <span className="text-[11px] font-bold px-3 py-1 rounded-full bg-[#080E1A]/80 backdrop-blur-md text-sky-300 border border-white/10">
                  {photo.categoryLabel}
                </span>
                <span className="w-8 h-8 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center text-white opacity-0 group-hover:opacity-100 transition-all transform translate-y-1 group-hover:translate-y-0">
                  <Eye className="w-4 h-4" />
                </span>
              </div>

              {/* Caption Bottom */}
              <div className="absolute bottom-3.5 inset-x-3.5 space-y-1">
                <h3 className="text-sm sm:text-base font-bold text-white font-outfit group-hover:text-sky-300 transition-colors">
                  {photo.title}
                </h3>
                <p className="text-xs text-slate-300 line-clamp-1">
                  {photo.caption}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom Banner */}
        <div className="mt-14 text-center">
          <p className="text-xs text-slate-400">
            * All images represent actual facilities and clinical environments at Masaraddi Neuro Care Center, Station Road, Bagalkot.
          </p>
        </div>

      </div>

      {/* Lightbox Modal */}
      {selectedImageIndex !== null && filteredPhotos[selectedImageIndex] && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-in fade-in duration-200">
          
          {/* Close Button */}
          <button
            onClick={closeLightbox}
            className="absolute top-5 right-5 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors z-10"
            aria-label="Close photo preview"
          >
            <X className="w-6 h-6" />
          </button>

          {/* Navigation Controls */}
          <button
            onClick={prevPhoto}
            className="absolute left-4 sm:left-8 top-1/2 -translate-y-1/2 p-3 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors z-10"
            aria-label="Previous photo"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>

          <button
            onClick={nextPhoto}
            className="absolute right-4 sm:right-8 top-1/2 -translate-y-1/2 p-3 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors z-10"
            aria-label="Next photo"
          >
            <ChevronRight className="w-6 h-6" />
          </button>

          {/* Active Image Container */}
          <div className="max-w-4xl w-full max-h-[85vh] flex flex-col items-center justify-center space-y-4">
            <div className="relative rounded-3xl overflow-hidden max-h-[70vh] border border-white/10 shadow-2xl">
              <img
                src={filteredPhotos[selectedImageIndex].image}
                alt={filteredPhotos[selectedImageIndex].altText || filteredPhotos[selectedImageIndex].title}
                className="max-h-[70vh] w-auto object-contain rounded-2xl"
              />
            </div>

            <div className="text-center space-y-1">
              <span className="text-xs font-bold text-sky-400">
                {filteredPhotos[selectedImageIndex].categoryLabel} · Photo {selectedImageIndex + 1} of {filteredPhotos.length}
              </span>
              <h3 className="text-lg font-bold text-white font-outfit">
                {filteredPhotos[selectedImageIndex].title}
              </h3>
              <p className="text-xs sm:text-sm text-slate-300 max-w-xl mx-auto">
                {filteredPhotos[selectedImageIndex].caption}
              </p>
            </div>
          </div>

        </div>
      )}
    </section>
  );
};
