import React from 'react';
import { Sparkles, MessageSquare } from 'lucide-react';

interface FloatingAITriggerProps {
  onOpen: () => void;
}

export const FloatingAITrigger: React.FC<FloatingAITriggerProps> = ({ onOpen }) => {
  return (
    <aside
      className="hidden md:flex fixed bottom-6 right-6 z-40 items-center group"
      aria-label="Ask Hospital AI Assistant"
    >
      {/* Tooltip Tag */}
      <div className="mr-3 px-3.5 py-1.5 rounded-xl bg-[#080E1A]/95 text-white text-xs font-semibold shadow-xl border border-sky-500/30 opacity-0 group-hover:opacity-100 transition-all duration-200 pointer-events-none translate-x-2 group-hover:translate-x-0">
        <span className="flex items-center gap-1.5">
          <Sparkles className="w-3.5 h-3.5 text-sky-400" />
          <span>Ask Masaraddi AI Assistant</span>
        </span>
      </div>

      {/* Pulsing Floating Button */}
      <button
        onClick={onOpen}
        className="relative p-3.5 rounded-2xl bg-gradient-to-br from-sky-500 via-sky-600 to-blue-600 hover:from-sky-400 hover:to-blue-500 text-white shadow-2xl shadow-sky-600/40 border border-white/20 transition-all duration-300 hover:scale-110 active:scale-95 focus:outline-none focus:ring-4 focus:ring-sky-400/40"
        aria-label="Open Masaraddi Neuro AI Assistant Modal"
      >
        <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-emerald-400 rounded-full animate-ping" />
        <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-emerald-400 rounded-full border-2 border-[#080E1A]" />
        
        <div className="flex items-center justify-center">
          <Sparkles className="w-6 h-6 text-white" />
        </div>
      </button>
    </aside>
  );
};
