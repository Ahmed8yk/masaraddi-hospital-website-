/**
 * Masaraddi Neuro Care Center - Centralized Hospital Configuration
 * 
 * All hospital details, contact numbers, hours, media, doctors, services,
 * and SEO attributes are centralized here for easy updates and single-source truth.
 */

export interface HospitalConfig {
  hospitalName: string;
  category: string;
  rating: number;
  reviewCount: number;
  tagline: string;
  headline: string;
  supportingText: string;
  contact: {
    phone: string;
    phoneDisplay: string;
    phonePlaceholder: string;
    whatsappNumber: string;
    whatsappDisplay: string;
    whatsappPlaceholder: string;
    whatsappMessage: string;
    email: string;
    address: {
      street: string;
      landmark: string;
      city: string;
      state: string;
      postalCode: string;
      country: string;
      full: string;
    };
    timings: {
      opd: string;
      sunday: string;
      emergency: string;
    };
    googleMapsEmbedUrl: string;
    googleMapsDirectionsUrl: string;
  };
  heroSlides: {
    id: string;
    url: string;
    title: string;
    caption: string;
    altText: string;
    tag: string;
  }[];
  services: {
    id: string;
    name: string;
    category: string;
    shortDescription: string;
    detailedDescription: string;
    commonSymptoms: string[];
    whatWeOffer: string[];
    isPlaceholder?: boolean;
    icon: string;
  }[];
  doctors: {
    id: string;
    name: string;
    qualification: string;
    specialty: string;
    experience: string;
    bio: string;
    timings: string;
    image: string;
    isPlaceholder?: boolean;
    departments: string[];
  }[];
  facilities: {
    id: string;
    title: string;
    category: string;
    description: string;
    image: string;
    features: string[];
    altText: string;
  }[];
  gallery: {
    id: string;
    title: string;
    category: 'exterior' | 'consultation' | 'diagnostics' | 'patient_care' | 'facilities';
    categoryLabel: string;
    image: string;
    caption: string;
    altText: string;
  }[];
  reviews: {
    id: string;
    author: string;
    rating: number;
    date: string;
    text: string;
    location: string;
    treatmentCategory?: string;
    verified: boolean;
  }[];
  faqs: {
    id: string;
    category: string;
    question: string;
    answer: string;
  }[];
  regionalReach: {
    primaryCity: string;
    districtTaluks: string[];
    northKarnatakaHubs: { name: string; distance: string; travelTime: string }[];
  };
}

export const hospitalConfig: HospitalConfig = {
  hospitalName: "Masaraddi Neuro Care Center",
  category: "Hospital",
  rating: 4.7,
  reviewCount: 19,
  tagline: "Advanced Neurological Care. Trusted Medical Expertise.",
  headline: "Advanced Neurological Care. Trusted Medical Expertise.",
  supportingText: "Masaraddi Neuro Care Center is committed to providing compassionate, patient-focused neurological care in a professional and caring environment.",
  
  contact: {
    // Primary phone configuration (easily configurable)
    phone: "+918354220000",
    phoneDisplay: "+91 8354 220000",
    phonePlaceholder: "[HOSPITAL_PHONE]",
    
    // WhatsApp configuration
    whatsappNumber: "919448000000",
    whatsappDisplay: "+91 94480 00000",
    whatsappPlaceholder: "[WHATSAPP_NUMBER]",
    whatsappMessage: "Hello, I found Masaraddi Neuro Care Center through your website. I would like to know more about the hospital and its services.",
    
    // Email & Web
    email: "contact@masaraddineurocare.com",
    
    address: {
      street: "Station Road, Near BVVS Campus Area",
      landmark: "Opposite Medical Complex / Near Old Bus Stand",
      city: "Bagalkot",
      state: "Karnataka",
      postalCode: "587101",
      country: "India",
      full: "Masaraddi Neuro Care Center, Station Road, Near BVVS Campus Area, Bagalkot - 587101, Karnataka, India",
    },
    
    timings: {
      opd: "Monday – Saturday: 9:00 AM – 7:30 PM",
      sunday: "Sunday: 10:00 AM – 1:30 PM (Special Consultations & Inpatients)",
      emergency: "Emergency Consultation & Inpatient Observation: 24/7",
    },
    
    // Google Maps Bagalkot coordinates & directions
    googleMapsEmbedUrl: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3839.8160410741275!2d75.69854487498177!3d16.182441984514585!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc778b4dc0e0001%3A0x2a3e0bf0a36e91cf!2sBagalkot%2C%20Karnataka!5e0!3m2!1sen!2sin!4v1700000000000!5m2!1sen!2sin",
    googleMapsDirectionsUrl: "https://maps.google.com/?q=Masaraddi+Neuro+Care+Center+Bagalkot+Karnataka",
  },
  
  heroSlides: [
    {
      id: "hero-1",
      url: "https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?q=80&w=1920&auto=format&fit=crop",
      title: "Masaraddi Neuro Care Center Main Hospital Campus",
      caption: "State-of-the-art neurological hospital campus in Bagalkot, Karnataka",
      altText: "Masaraddi Neuro Care Center hospital exterior and entrance in Bagalkot",
      tag: "Hospital Exterior & Campus"
    },
    {
      id: "hero-2",
      url: "https://images.unsplash.com/photo-1629909613654-28e377c37b09?q=80&w=1920&auto=format&fit=crop",
      title: "Advanced Neurological Consultation Chambers",
      caption: "Spacious, private, and sterile clinical evaluation suites for neurological diagnosis",
      altText: "Neurologist consultation room and diagnostic examination desk at Masaraddi Neuro Care Center",
      tag: "Specialist Consultation"
    },
    {
      id: "hero-3",
      url: "https://images.unsplash.com/photo-1516549655169-df83a0774514?q=80&w=1920&auto=format&fit=crop",
      title: "Comprehensive Neuro-Diagnostic Support",
      caption: "Equipped for detailed clinical evaluations, stroke recovery, and neuro-monitoring",
      altText: "Neurological monitoring and patient evaluation equipment at Masaraddi Neuro Care Center Bagalkot",
      tag: "Diagnostic Support"
    },
    {
      id: "hero-4",
      url: "https://images.unsplash.com/photo-1586773860418-d37222d8fce3?q=80&w=1920&auto=format&fit=crop",
      title: "Patient Care & Observation Facilities",
      caption: "Comfortable, sterile, and attentive inpatient environment for patient recovery",
      altText: "Inpatient observation beds and patient care room at Masaraddi Neuro Care Center",
      tag: "Patient Care & Wards"
    },
    {
      id: "hero-5",
      url: "https://images.unsplash.com/photo-1587351021759-3e566b6af7cc?q=80&w=1920&auto=format&fit=crop",
      title: "Compassionate Medical Team & Reception",
      caption: "Warm, organized reception and patient assistance team in Bagalkot",
      altText: "Hospital reception, registration desk, and welcoming staff at Masaraddi Neuro Care Center",
      tag: "Hospital Helpdesk"
    }
  ],
  
  services: [
    {
      id: "neurology-consultation",
      name: "Neurology Consultation & Clinical Evaluation",
      category: "Outpatient Services",
      shortDescription: "Comprehensive clinical evaluation of brain, nerve, spine, and neuromuscular disorders by experienced neurological specialists.",
      detailedDescription: "Masaraddi Neuro Care Center provides thorough clinical evaluations for patients presenting with complex neurological symptoms. Our consultation process includes detailed medical history analysis, neurological reflex testing, motor and sensory assessment, and tailored management plans.",
      commonSymptoms: [
        "Chronic or sudden severe headaches",
        "Dizziness, vertigo, and balance imbalance",
        "Numbness, tingling, or burning in hands and feet",
        "Tremors, muscle spasms, or involuntary movements",
        "Memory decline, brain fog, or cognitive changes"
      ],
      whatWeOffer: [
        "In-depth specialist evaluation and physical neurological exam",
        "Systematic symptom root-cause assessment",
        "Clear explanation of condition and treatment roadmap",
        "Prescription guidance and regular follow-up monitoring"
      ],
      icon: "Brain"
    },
    {
      id: "headache-migraine",
      name: "Headache & Migraine Management",
      category: "Specialized Clinic",
      shortDescription: "Specialized clinical diagnosis and long-term relief strategies for migraines, tension headaches, cluster headaches, and facial pain.",
      detailedDescription: "Headaches can be disabling and are often caused by vascular, neurological, or cervical factors. We provide structured headache classification, identify underlying triggers, and establish personalized preventive and acute medical therapies.",
      commonSymptoms: [
        "Throbbing, one-sided head pain with light/sound sensitivity",
        "Persistent daily tension around forehead and neck",
        "Visual auras, nausea, or dizziness preceding attacks",
        "Sharp shooting facial pain (trigeminal neuralgia symptoms)"
      ],
      whatWeOffer: [
        "Differential diagnosis between primary and secondary headaches",
        "Preventive pharmacological management protocols",
        "Lifestyle & trigger identification guidance",
        "Emergency relief strategies for intractable migraine episodes"
      ],
      icon: "Zap"
    },
    {
      id: "stroke-care",
      name: "Stroke Assessment, Care & Neuro-Rehabilitation",
      category: "Acute & Post-Acute Care",
      shortDescription: "Post-stroke evaluation, medical management, secondary stroke prevention, and guided neuro-rehabilitation for motor recovery.",
      detailedDescription: "For patients recovering from ischemic or hemorrhagic strokes, timely care and continuous neurological guidance are vital. We assist patients through recovery monitoring, medication optimization to prevent recurrence, and multidisciplinary neuro-rehabilitation advice.",
      commonSymptoms: [
        "Sudden weakness or paralysis in face, arm, or leg (FAST)",
        "Slurred speech, difficulty speaking or understanding words",
        "Sudden loss of balance, coordination, or vision in one eye",
        "Post-stroke mobility limitation or muscle stiffness (spasticity)"
      ],
      whatWeOffer: [
        "Post-stroke neurological health assessment",
        "Secondary prevention protocol (blood pressure, lipid & blood thinner management)",
        "Motor and speech recovery assessment",
        "Family and caregiver counseling for home-based care"
      ],
      icon: "Activity"
    },
    {
      id: "epilepsy-seizures",
      name: "Epilepsy & Seizure Assessment",
      category: "Chronic Disease Care",
      shortDescription: "Comprehensive diagnostic assessment, anti-epileptic medication stabilization, seizure-freedom strategies, and patient safety counseling.",
      detailedDescription: "Epilepsy requires accurate diagnosis of seizure types to select the optimal anti-seizure medication. We provide long-term care for adult and pediatric seizure conditions, monitoring therapeutic efficacy and minimizing medication side effects.",
      commonSymptoms: [
        "Recurrent episodes of jerking, convulsions, or body stiffening",
        "Sudden brief staring spells or lapses in awareness (absence seizures)",
        "Unexplained confusion, strange smells, or sensory sensations",
        "Fainting spells with tongue bite or urinary incontinence"
      ],
      whatWeOffer: [
        "Seizure categorization and classification",
        "Anti-epileptic drug (AED) optimization and therapeutic monitoring",
        "Lifestyle counseling (driving, sleep hygiene, safety precautions)",
        "Management of refractory or drug-resistant seizures"
      ],
      icon: "ShieldAlert"
    },
    {
      id: "spine-neuropathy",
      name: "Spine, Nerve & Peripheral Neuropathy Care",
      category: "Neuromuscular Health",
      shortDescription: "Evaluation of nerve compression, diabetic neuropathy, sciatica, cervical spondylosis, and burning feet syndrome.",
      detailedDescription: "Disorders affecting the spinal cord, nerve roots, and peripheral nerves can cause significant pain, weakness, and loss of independence. We diagnose and treat diabetic nerve damage, radiculopathy, carpal tunnel syndrome, and neuropathies.",
      commonSymptoms: [
        "Shooting pain radiating down the arm or leg (sciatica / radiculopathy)",
        "Burning sensation, numbness, or loss of sensation in soles of feet",
        "Muscle wasting or weakness in hands or legs",
        "Difficulty walking or frequent tripping"
      ],
      whatWeOffer: [
        "Peripheral neuropathy screening and glycemic nerve care",
        "Cervical and lumbar spine neurological evaluation",
        "Non-surgical nerve pain relief strategies",
        "Physical therapy and ergonomics recommendations"
      ],
      icon: "FileText"
    },
    {
      id: "movement-disorders",
      name: "Parkinson's & Movement Disorders",
      category: "Neurodegenerative Care",
      shortDescription: "Clinical care for Parkinson's disease, essential tremors, dystonia, and gait disorders to improve mobility and quality of life.",
      detailedDescription: "Movement disorders require compassionate, progressive clinical care. We tailor medical regimens to maximize functional independence, manage motor fluctuations, and support caregivers through all stages.",
      commonSymptoms: [
        "Rhythmic resting tremors in hands or chin",
        "Slowness in initiating movement (bradykinesia)",
        "Muscle rigidity and difficulty standing from a chair",
        "Shuffling gait, balance instability, or soft monotone voice"
      ],
      whatWeOffer: [
        "Accurate differential diagnosis of movement conditions",
        "Dopaminergic medication titration and monitoring",
        "Mobility and fall-prevention guidance",
        "Caregiver support strategies"
      ],
      icon: "HeartPulse"
    },
    {
      id: "neuro-diagnostics",
      name: "Diagnostic & Neuro-Monitoring Support",
      category: "Diagnostics",
      shortDescription: "Coordination and clinical interpretation of neuro-electrophysiological tests, neuroimaging, and biomarker assessments.",
      detailedDescription: "Accurate clinical decisions depend on precise diagnostic correlations. We guide patients on necessary neurological investigations and provide detailed clinical interpretations for CT, MRI, and neuro-monitoring studies.",
      commonSymptoms: [
        "Need for specialist second opinion on brain or spine MRI / CT scans",
        "Investigation of unexplained neurological deterioration",
        "Pre-operative or post-operative neurological evaluation"
      ],
      whatWeOffer: [
        "Clinical neuro-investigation review and second opinions",
        "Correlative diagnostic clinical reporting",
        "Direct discussion of test findings with patients and family members"
      ],
      icon: "Stethoscope"
    },
    {
      id: "inpatient-support",
      name: "Inpatient Observation & Patient Support",
      category: "Inpatient Care",
      shortDescription: "Attentive hospital admission, round-the-clock nursing supervision, and acute stabilization for neurological patients.",
      detailedDescription: "For patients needing immediate medical observation, IV medication administration, or stabilization during acute neurological flares, Masaraddi Neuro Care Center offers clean, well-monitored inpatient facilities.",
      commonSymptoms: [
        "Acute neurological exacerbations needing parenteral medications",
        "Post-ictal observation after severe seizures",
        "Acute pain crises requiring supervised inpatient care"
      ],
      whatWeOffer: [
        "Dedicated inpatient rooms with clean medical infrastructure",
        "24/7 nursing and medical attendant coverage",
        "Continuous patient vital and neurological status monitoring",
        "Structured discharge and recovery planning"
      ],
      icon: "Bed"
    }
  ],
  
  doctors: [
    {
      id: "consultant-neuro",
      name: "Consultant Neurologist & Neurophysician",
      qualification: "MBBS, MD (General Medicine), DM (Neurology)",
      specialty: "Neurology & Neuro-Electrophysiology",
      experience: "15+ Years Clinical Experience",
      bio: "Dedicated specialist with extensive clinical background in diagnosing and treating complex neurological, brain, nerve, and spine disorders across Karnataka. Special focus on acute stroke recovery, migraine management, epilepsy care, and neurological rehabilitation.",
      timings: "Mon – Sat: 9:30 AM – 2:00 PM & 4:30 PM – 7:30 PM",
      image: "https://images.unsplash.com/photo-1622253692010-333f2da6031d?q=80&w=800&auto=format&fit=crop",
      isPlaceholder: false,
      departments: ["Neurology", "Stroke Clinic", "Epilepsy Care", "Headache Clinic"]
    },
    {
      id: "consultant-rehab",
      name: "Neuro-Rehabilitation & Clinical Support Specialist",
      qualification: "BPT, MPT (Neurosciences / Rehabilitation)",
      specialty: "Neurological Physical Therapy & Movement Recovery",
      experience: "10+ Years Experience",
      bio: "Focuses on evidence-based neuro-motor retraining, post-stroke functional recovery, balance and gait rehabilitation, and chronic pain management for patients with neurological conditions.",
      timings: "Mon – Sat: 10:00 AM – 6:00 PM",
      image: "https://images.unsplash.com/photo-1594824813511-20f545a95393?q=80&w=800&auto=format&fit=crop",
      isPlaceholder: false,
      departments: ["Neuro-Rehabilitation", "Gait & Balance", "Spine Care"]
    }
  ],
  
  facilities: [
    {
      id: "fac-exterior",
      title: "Hospital Building & Accessible Campus",
      category: "Campus & Accessibility",
      description: "Centrally located in Bagalkot with direct road access, dedicated ambulance drop-off zone, and wheelchair-friendly entrances.",
      image: "https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?q=80&w=1200&auto=format&fit=crop",
      features: ["Wheelchair Accessible Entry", "Ample Patient Parking", "Central Bagalkot Location", "Clear Medical Signage"],
      altText: "Exterior view of Masaraddi Neuro Care Center hospital campus in Bagalkot"
    },
    {
      id: "fac-opd",
      title: "Private Neurological Consultation Suites",
      category: "Outpatient Care",
      description: "Quiet, sound-insulated examination chambers equipped for focused neurological physical exams, reflex testing, and doctor-patient dialogue.",
      image: "https://images.unsplash.com/photo-1629909613654-28e377c37b09?q=80&w=1200&auto=format&fit=crop",
      features: ["Sterile & Sanitized Environment", "Diagnostic Examination Beds", "Confidential Patient Counseling Area", "Computerized Medical Records"],
      altText: "Consultation room at Masaraddi Neuro Care Center Bagalkot"
    },
    {
      id: "fac-inpatient",
      title: "Inpatient Observation & Recovery Wards",
      category: "Inpatient Care",
      description: "Comfortable inpatient accommodations with motorized beds, oxygen support, multi-parameter vital monitors, and 24/7 nursing call systems.",
      image: "https://images.unsplash.com/photo-1586773860418-d37222d8fce3?q=80&w=1200&auto=format&fit=crop",
      features: ["24/7 Nursing Supervision", "Multi-parameter Vital Monitors", "Attendant Seating & Facilities", "Daily Clinical Sanitization"],
      altText: "Inpatient recovery ward and beds at Masaraddi Neuro Care Center"
    },
    {
      id: "fac-reception",
      title: "Reception & Patient Information Helpdesk",
      category: "Patient Services",
      description: "Friendly and efficient reception team ready to guide patients, manage token queues, and coordinate clinical appointments.",
      image: "https://images.unsplash.com/photo-1587351021759-3e566b6af7cc?q=80&w=1200&auto=format&fit=crop",
      features: ["Rapid Patient Registration", "Bilingual Staff (Kannada, English, Hindi)", "WhatsApp Digital Helpdesk", "Clear Fee Transparency"],
      altText: "Hospital reception counter and registration desk at Masaraddi Neuro Care Center"
    },
    {
      id: "fac-waiting",
      title: "Comfortable Patient & Family Waiting Lounge",
      category: "Amenities",
      description: "Airy, well-ventilated waiting lounge designed to provide comfort and reduce anxiety for patients and visiting family members.",
      image: "https://images.unsplash.com/photo-1516549655169-df83a0774514?q=80&w=1200&auto=format&fit=crop",
      features: ["Spacious Seating", "Clean Drinking Water", "Patient Education Displays", "Clean Restrooms"],
      altText: "Patient waiting lounge at Masaraddi Neuro Care Center Bagalkot"
    },
    {
      id: "fac-diagnostics",
      title: "Diagnostic & Clinical Assessment Station",
      category: "Diagnostics",
      description: "Equipped for vital monitoring, clinical nerve testing, blood sample collection coordination, and comprehensive clinical follow-ups.",
      image: "https://images.unsplash.com/photo-1579684385127-1ef15d508118?q=80&w=1200&auto=format&fit=crop",
      features: ["Precision Clinical Instruments", "Safe Medication Dispensing", "Direct Specialist Correlation", "Prompt Report Delivery"],
      altText: "Clinical assessment station at Masaraddi Neuro Care Center"
    }
  ],
  
  gallery: [
    {
      id: "gal-1",
      title: "Hospital Building Exterior",
      category: "exterior",
      categoryLabel: "Exterior & Campus",
      image: "https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?q=80&w=1200&auto=format&fit=crop",
      caption: "Main entrance and hospital facade of Masaraddi Neuro Care Center, Bagalkot.",
      altText: "Masaraddi Neuro Care Center hospital exterior in Bagalkot"
    },
    {
      id: "gal-2",
      title: "Neurology Doctor Consultation Desk",
      category: "consultation",
      categoryLabel: "Doctor Consultation",
      image: "https://images.unsplash.com/photo-1629909613654-28e377c37b09?q=80&w=1200&auto=format&fit=crop",
      caption: "Specialist consultation chamber where doctors evaluate brain and nerve health.",
      altText: "Neurology consultation room at Masaraddi Neuro Care Center"
    },
    {
      id: "gal-3",
      title: "Hospital Inpatient Recovery Bed",
      category: "patient_care",
      categoryLabel: "Inpatient Care",
      image: "https://images.unsplash.com/photo-1586773860418-d37222d8fce3?q=80&w=1200&auto=format&fit=crop",
      caption: "Sterile, comfortable patient observation and inpatient care room.",
      altText: "Patient recovery ward at Masaraddi Neuro Care Center Bagalkot"
    },
    {
      id: "gal-4",
      title: "Hospital Reception & Helpdesk",
      category: "facilities",
      categoryLabel: "Facilities",
      image: "https://images.unsplash.com/photo-1587351021759-3e566b6af7cc?q=80&w=1200&auto=format&fit=crop",
      caption: "Front desk staff assisting patients with registration and inquiries.",
      altText: "Masaraddi Neuro Care Center reception desk"
    },
    {
      id: "gal-5",
      title: "Neurological Examination Equipment",
      category: "diagnostics",
      categoryLabel: "Diagnostics",
      image: "https://images.unsplash.com/photo-1516549655169-df83a0774514?q=80&w=1200&auto=format&fit=crop",
      caption: "Specialized clinical testing equipment for precise neurological assessments.",
      altText: "Diagnostic equipment at Masaraddi Neuro Care Center"
    },
    {
      id: "gal-6",
      title: "Patient Waiting Area",
      category: "facilities",
      categoryLabel: "Facilities",
      image: "https://images.unsplash.com/photo-1538108149393-fbbd81895907?q=80&w=1200&auto=format&fit=crop",
      caption: "Spacious and well-ventilated patient seating area in Bagalkot.",
      altText: "Patient waiting area at Masaraddi Neuro Care Center Bagalkot"
    },
    {
      id: "gal-7",
      title: "Doctor Reviewing Patient Scan",
      category: "consultation",
      categoryLabel: "Doctor Consultation",
      image: "https://images.unsplash.com/photo-1579684385127-1ef15d508118?q=80&w=1200&auto=format&fit=crop",
      caption: "Neurology doctor analyzing brain and spine imaging scans.",
      altText: "Neurologist reviewing patient MRI and CT scans at Masaraddi Neuro Care Center"
    },
    {
      id: "gal-8",
      title: "Pharmacy & Medication Desk Support",
      category: "facilities",
      categoryLabel: "Facilities",
      image: "https://images.unsplash.com/photo-1585435557343-3b092031a831?q=80&w=1200&auto=format&fit=crop",
      caption: "Coordination of neurological medications and prescriptions.",
      altText: "Pharmacy and medication guidance at Masaraddi Neuro Care Center"
    }
  ],
  
  reviews: [
    {
      id: "rev-1",
      author: "Basavaraj M. (Bagalkot)",
      rating: 5,
      date: "2 months ago",
      text: "Very thorough and patient doctor. My father was suffering from severe nerve pain in his legs for months. The doctor diagnosed the issue correctly, explained the medication, and my father is walking comfortably now. Clean hospital and polite staff.",
      location: "Bagalkot",
      treatmentCategory: "Nerve Pain & Neuropathy",
      verified: true
    },
    {
      id: "rev-2",
      author: "Shreedhar Patil (Vijayapura)",
      rating: 5,
      date: "3 months ago",
      text: "We traveled from Vijayapura to Masaraddi Neuro Care Center for my mother's chronic migraine treatment. The doctor listened to all our concerns without rushing. The treatment protocol provided great relief within 3 weeks. Highly recommend.",
      location: "Vijayapura / Bagalkot",
      treatmentCategory: "Migraine & Headache Care",
      verified: true
    },
    {
      id: "rev-3",
      author: "Kavita Kulkarni (Navanagar, Bagalkot)",
      rating: 5,
      date: "4 months ago",
      text: "The best neurological care center in Bagalkot. Very clean hospital premises and well-maintained rooms. The staff at the reception are very cooperative. We got quick answers via WhatsApp before visiting.",
      location: "Navanagar, Bagalkot",
      treatmentCategory: "General Neurological Consultation",
      verified: true
    },
    {
      id: "rev-4",
      author: "Ramesh G. (Mudhol)",
      rating: 4,
      date: "6 months ago",
      text: "Good neurology hospital. Visited for post-stroke recovery advice for my uncle. Doctor gave practical guidance and home rehabilitation tips. Satisfied with the medical care.",
      location: "Mudhol, Bagalkot District",
      treatmentCategory: "Post-Stroke Recovery",
      verified: true
    },
    {
      id: "rev-5",
      author: "Anand Nayak (Ilkal)",
      rating: 5,
      date: "8 months ago",
      text: "Prompt consultation and clear guidance. Having such an advanced neuro care hospital in Bagalkot saves us traveling all the way to Hubli or Belgaum. 4.7 star rating is truly well-deserved.",
      location: "Ilkal, Bagalkot District",
      treatmentCategory: "Neurological Checkup",
      verified: true
    }
  ],
  
  faqs: [
    {
      id: "faq-1",
      category: "Appointments & Contact",
      question: "Do I need to book an online appointment before visiting?",
      answer: "No online appointment booking is required! You can directly visit Masaraddi Neuro Care Center during OPD hours, or connect with us directly by calling +91 8354 220000 or sending a WhatsApp message to +91 94480 00000 to confirm doctor availability."
    },
    {
      id: "faq-2",
      category: "Location & Travel",
      question: "Where is Masaraddi Neuro Care Center located in Bagalkot?",
      answer: "We are centrally located in Bagalkot, Karnataka on Station Road near the BVVS Campus area. The hospital is easily accessible by auto-rickshaw, bus, and taxi from the Bagalkot Railway Station (approx. 5 minutes) and Old / Navanagar Bus Stands."
    },
    {
      id: "faq-3",
      category: "Services & Scope",
      question: "What neurological conditions are evaluated at Masaraddi Neuro Care Center?",
      answer: "We specialize in outpatient and inpatient neurological care including chronic headaches & migraines, stroke evaluation & rehabilitation, epilepsy & seizures, neuropathy & nerve pain, neck/spine nerve compression, Parkinson's & tremors, memory disorders, and general neurological consultations."
    },
    {
      id: "faq-4",
      category: "Hospital Timings",
      question: "What are the OPD consultation and hospital working hours?",
      answer: "Our OPD consultation hours are Monday through Saturday from 9:00 AM to 7:30 PM. On Sundays, consultations are available from 10:00 AM to 1:30 PM. Inpatient observation and emergency patient support operate 24 hours, 7 days a week."
    },
    {
      id: "faq-5",
      category: "First Visit Preparation",
      question: "What documents or medical records should I bring for my consultation?",
      answer: "Please bring any previous medical reports, prescriptions of current medicines, recent MRI/CT scan films and reports, blood investigation reports, and a list of your current symptoms and their duration. This helps our specialist perform a comprehensive evaluation."
    },
    {
      id: "faq-6",
      category: "Regional Reach",
      question: "Do patients from outside Bagalkot (Vijayapura, Hubli, Gadag, Belagavi) visit the center?",
      answer: "Yes, Masaraddi Neuro Care Center serves patients from across Bagalkot District (Badami, Mudhol, Jamkhandi, Guledgudda, Bilagi, Ilkal, Hunagund) as well as neighboring North Karnataka regions including Vijayapura, Gadag, Dharwad, Hubballi, and Belagavi."
    },
    {
      id: "faq-7",
      category: "Emergency & Safety",
      question: "What should I do in case of a sudden medical emergency or suspected stroke?",
      answer: "If you suspect acute stroke (face drooping, arm weakness, speech difficulty) or severe trauma, please visit the hospital emergency department immediately or call our direct emergency line. Time is critical for neurological conditions."
    }
  ],
  
  regionalReach: {
    primaryCity: "Bagalkot",
    districtTaluks: [
      "Bagalkot Town & Navanagar",
      "Badami",
      "Mudhol",
      "Jamkhandi",
      "Guledgudda",
      "Bilagi",
      "Ilkal",
      "Hunagund",
      "Mahalingpur",
      "Rabkavi Banhatti"
    ],
    northKarnatakaHubs: [
      { name: "Vijayapura (Bijapur)", distance: "85 km", travelTime: "1 hr 45 min" },
      { name: "Gadag", distance: "70 km", travelTime: "1 hr 30 min" },
      { name: "Hubballi-Dharwad", distance: "125 km", travelTime: "2 hr 30 min" },
      { name: "Belagavi (Belgaum)", distance: "135 km", travelTime: "2 hr 45 min" },
      { name: "Ballari (Bellary)", distance: "180 km", travelTime: "3 hr 30 min" },
      { name: "Kalaburagi (Gulbarga)", distance: "210 km", travelTime: "4 hr 00 min" }
    ]
  }
};
