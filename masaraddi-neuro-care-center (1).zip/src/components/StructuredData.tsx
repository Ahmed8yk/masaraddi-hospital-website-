import React, { useEffect } from 'react';
import { hospitalConfig } from '../config/hospitalConfig';

export const StructuredData: React.FC = () => {
  useEffect(() => {
    // MedicalOrganization & Hospital Schema
    const hospitalSchema = {
      "@context": "https://schema.org",
      "@type": ["Hospital", "MedicalOrganization", "MedicalBusiness"],
      "name": hospitalConfig.hospitalName,
      "alternateName": "Masaraddi Neuro Care",
      "description": hospitalConfig.supportingText,
      "url": "https://masaraddineurocare.com",
      "logo": "https://masaraddineurocare.com/logo.png",
      "image": hospitalConfig.heroSlides.map(s => s.url),
      "telephone": hospitalConfig.contact.phone,
      "priceRange": "$$",
      "address": {
        "@type": "PostalAddress",
        "streetAddress": hospitalConfig.contact.address.street,
        "addressLocality": hospitalConfig.contact.address.city,
        "addressRegion": hospitalConfig.contact.address.state,
        "postalCode": hospitalConfig.contact.address.postalCode,
        "addressCountry": "IN"
      },
      "geo": {
        "@type": "GeoCoordinates",
        "latitude": 16.182442,
        "longitude": 75.698545
      },
      "openingHoursSpecification": [
        {
          "@type": "OpeningHoursSpecification",
          "dayOfWeek": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
          "opens": "09:00",
          "closes": "19:30"
        },
        {
          "@type": "OpeningHoursSpecification",
          "dayOfWeek": ["Sunday"],
          "opens": "10:00",
          "closes": "13:30"
        }
      ],
      "aggregateRating": {
        "@type": "AggregateRating",
        "ratingValue": hospitalConfig.rating.toString(),
        "reviewCount": hospitalConfig.reviewCount.toString(),
        "bestRating": "5",
        "worstRating": "1"
      },
      "medicalSpecialty": [
        "https://schema.org/Neurology"
      ],
      "availableService": hospitalConfig.services.map(s => ({
        "@type": "MedicalProcedure",
        "name": s.name,
        "description": s.shortDescription
      })),
      "areaServed": [
        {
          "@type": "AdministrativeArea",
          "name": "Bagalkot"
        },
        {
          "@type": "AdministrativeArea",
          "name": "Vijayapura"
        },
        {
          "@type": "AdministrativeArea",
          "name": "Gadag"
        },
        {
          "@type": "AdministrativeArea",
          "name": "North Karnataka"
        },
        {
          "@type": "AdministrativeArea",
          "name": "Karnataka"
        }
      ]
    };

    // FAQPage Schema
    const faqSchema = {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": hospitalConfig.faqs.map(faq => ({
        "@type": "Question",
        "name": faq.question,
        "acceptedAnswer": {
          "@type": "Answer",
          "text": faq.answer
        }
      }))
    };

    // BreadcrumbList Schema
    const breadcrumbSchema = {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        {
          "@type": "ListItem",
          "position": 1,
          "name": "Home",
          "item": "https://masaraddineurocare.com/"
        },
        {
          "@type": "ListItem",
          "position": 2,
          "name": "About Masaraddi Neuro Care Center",
          "item": "https://masaraddineurocare.com/#about"
        },
        {
          "@type": "ListItem",
          "position": 3,
          "name": "Neurology Services",
          "item": "https://masaraddineurocare.com/#services"
        },
        {
          "@type": "ListItem",
          "position": 4,
          "name": "Neurologists & Specialists",
          "item": "https://masaraddineurocare.com/#doctors"
        },
        {
          "@type": "ListItem",
          "position": 5,
          "name": "Hospital Facilities & Gallery",
          "item": "https://masaraddineurocare.com/#facilities"
        },
        {
          "@type": "ListItem",
          "position": 6,
          "name": "Contact & Location in Bagalkot",
          "item": "https://masaraddineurocare.com/#contact"
        }
      ]
    };

    // Inject into head
    const script1 = document.createElement('script');
    script1.type = 'application/ld+json';
    script1.text = JSON.stringify(hospitalSchema);
    document.head.appendChild(script1);

    const script2 = document.createElement('script');
    script2.type = 'application/ld+json';
    script2.text = JSON.stringify(faqSchema);
    document.head.appendChild(script2);

    const script3 = document.createElement('script');
    script3.type = 'application/ld+json';
    script3.text = JSON.stringify(breadcrumbSchema);
    document.head.appendChild(script3);

    return () => {
      if (document.head.contains(script1)) document.head.removeChild(script1);
      if (document.head.contains(script2)) document.head.removeChild(script2);
      if (document.head.contains(script3)) document.head.removeChild(script3);
    };
  }, []);

  return null;
};
