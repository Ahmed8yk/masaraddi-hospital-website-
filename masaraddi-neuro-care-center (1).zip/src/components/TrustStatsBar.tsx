import React from 'react';
import { Star, ShieldCheck, MapPin, Award, Users, Stethoscope, HeartPulse } from 'lucide-react';
import { hospitalConfig } from '../config/hospitalConfig';

export const TrustStatsBar: React.FC = () => {
  return (
    <section className="relative z-20 -mt-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="bg-white/95 backdrop-blur-xl rounded-3xl p-6 sm:p-8 shadow-[0_20px_50px_rgba(15,23,42,0.08)] border border-slate-200/80 transition-all duration-300">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8 divide-y lg:divide-y-0 lg:divide-x divide-slate-100">
          
          {/* Stat 1: Google Rating */}
          <div className="flex items-center gap-4 pt-4 first:pt-0 lg:pt-0 lg:px-4">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center shrink-0">
              <Star className="w-6 h-6 fill-amber-500 text-amber-500" />
            </div>
            <div>
              <div className="flex items-baseline gap-1.5">
                <span className="text-2xl sm:text-3xl font-extrabold text-[#0B132B] font-outfit">
                  {hospitalConfig.rating}
                </span>
                <span className="text-xs font-bold text-amber-600 uppercase tracking-wider">/ 5.0</span>
              </div>
              <p className="text-xs sm:text-sm font-semibold text-slate-600 mt-0.5">
                {hospitalConfig.reviewCount} Verified Reviews
              </p>
            </div>
          </div>

          {/* Stat 2: Neurological Specialization */}
          <div className="flex items-center gap-4 pt-4 lg:pt-0 lg:px-4">
            <div className="w-12 h-12 rounded-2xl bg-sky-500/10 border border-sky-500/20 flex items-center justify-center shrink-0">
              <HeartPulse className="w-6 h-6 text-sky-600" />
            </div>
            <div>
              <div className="text-2xl sm:text-3xl font-extrabold text-[#0B132B] font-outfit">
                Specialized
              </div>
              <p className="text-xs sm:text-sm font-semibold text-slate-600 mt-0.5">
                Neuro & Spine Center
              </p>
            </div>
          </div>

          {/* Stat 3: Inpatient & OPD Services */}
          <div className="flex items-center gap-4 pt-4 lg:pt-0 lg:px-4">
            <div className="w-12 h-12 rounded-2xl bg-teal-500/10 border border-teal-500/20 flex items-center justify-center shrink-0">
              <Stethoscope className="w-6 h-6 text-teal-600" />
            </div>
            <div>
              <div className="text-2xl sm:text-3xl font-extrabold text-[#0B132B] font-outfit">
                OPD & IPD
              </div>
              <p className="text-xs sm:text-sm font-semibold text-slate-600 mt-0.5">
                Dedicated Clinical Wards
              </p>
            </div>
          </div>

          {/* Stat 4: Bagalkot Hub */}
          <div className="flex items-center gap-4 pt-4 lg:pt-0 lg:px-4">
            <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center shrink-0">
              <MapPin className="w-6 h-6 text-indigo-600" />
            </div>
            <div>
              <div className="text-2xl sm:text-3xl font-extrabold text-[#0B132B] font-outfit">
                Bagalkot
              </div>
              <p className="text-xs sm:text-sm font-semibold text-slate-600 mt-0.5">
                Station Road Hub
              </p>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
