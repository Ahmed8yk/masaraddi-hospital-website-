import React from 'react';
import { 
  Building2, 
  MapPin, 
  Star, 
  CheckCircle2, 
  Clock, 
  Phone, 
  ShieldCheck, 
  HeartHandshake, 
  Award,
  Users
} from 'lucide-react';
import { hospitalConfig } from '../config/hospitalConfig';

export const AboutSection: React.FC = () => {
  const values = [
    {
      icon: HeartHandshake,
      title: 'Compassionate Care',
      desc: 'Treating neurological disorders with empathy, personalized listening, and patient-first medical counseling.',
      badgeColor: 'bg-rose-50 text-rose-600 border-rose-100',
    },
    {
      icon: ShieldCheck,
      title: 'Clinical Accuracy',
      desc: 'Rigorous diagnostic protocols, comprehensive nerve/brain assessments, and evidence-based treatment plans.',
      badgeColor: 'bg-sky-50 text-sky-600 border-sky-100',
    },
    {
      icon: Building2,
      title: 'Integrated Center',
      desc: 'Under-one-roof OPD clinics, dedicated inpatient monitoring beds, pharmacy, and diagnostic observation units.',
      badgeColor: 'bg-indigo-50 text-indigo-600 border-indigo-100',
    },
    {
      icon: Award,
      title: 'Regional Trust',
      desc: 'Serving families across Bagalkot, Mudhol, Badami, Jamkhandi, Bilagi, Guledagudda, and Ilkal.',
      badgeColor: 'bg-teal-50 text-teal-600 border-teal-100',
    },
  ];

  const keyHighlights = [
    "Specialized Brain, Spine & Neurological Care",
    "Evidence-based headache & migraine protocols",
    "Post-stroke assessment & neuro-rehab guidance",
    "Long-term epilepsy & seizure management",
    "Clean inpatient observation facilities",
    "Convenient central location on Station Road"
  ];

  return (
    <section id="about" className="py-24 bg-[#F8FAFC] relative overflow-hidden">
      {/* Subtle Ambient Glow */}
      <div className="absolute top-1/2 left-0 -translate-y-1/2 w-96 h-96 bg-sky-100/50 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-indigo-100/50 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-sky-100/80 border border-sky-200 text-sky-800 text-xs font-bold tracking-wide uppercase shadow-sm">
            <ShieldCheck className="w-3.5 h-3.5 text-sky-600" />
            <span>About Our Neurological Center</span>
          </div>
          
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#0B132B] tracking-tight font-outfit">
            Excellence in Neurological & Brain Health in Bagalkot
          </h2>
          
          <p className="text-base sm:text-lg text-slate-600 leading-relaxed">
            {hospitalConfig.supportingText}
          </p>
        </div>

        {/* 2-Column Content Grid: Story & Visual Highlights */}
        <div className="mt-16 grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          
          {/* Left Column: Hospital Overview Card */}
          <div className="lg:col-span-7 space-y-6">
            <div className="bg-white rounded-3xl p-8 sm:p-10 border border-slate-200/80 shadow-[0_10px_30px_rgba(0,0,0,0.03)] space-y-6">
              
              <div className="space-y-3">
                <span className="text-xs font-bold text-sky-600 uppercase tracking-wider">
                  Our Mission & Clinical Focus
                </span>
                <h3 className="text-2xl font-bold text-[#0B132B] font-outfit">
                  Patient-Centered Neurological Diagnostics & Long-Term Management
                </h3>
                <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
                  Masaraddi Neuro Care Center stands as a dedicated neurology healthcare destination in Bagalkot, offering structured clinical consultations, specialized nerve and brain disorder evaluations, and supportive inpatient observation for acute and chronic conditions.
                </p>
              </div>

              {/* Key Distinct Strengths */}
              <div className="pt-2 grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                {keyHighlights.map((highlight, index) => (
                  <div 
                    key={index}
                    className="flex items-start gap-2.5 p-3 rounded-2xl bg-slate-50 border border-slate-100"
                  >
                    <CheckCircle2 className="w-4 h-4 text-sky-600 shrink-0 mt-0.5" />
                    <span className="text-xs font-semibold text-slate-700 leading-snug">
                      {highlight}
                    </span>
                  </div>
                ))}
              </div>

              {/* Station Road Location Callout Card */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-sky-50 to-indigo-50 border border-sky-100/80 flex items-start gap-3">
                <MapPin className="w-5 h-5 text-sky-600 shrink-0 mt-0.5" />
                <div className="text-xs text-slate-700">
                  <span className="font-bold text-[#0B132B] block">Conveniently Located on Station Road</span>
                  Accessible to patients traveling by bus, train, or regional road transit from across North Karnataka districts.
                </div>
              </div>

            </div>
          </div>

          {/* Right Column: Values & Fast Facts */}
          <div className="lg:col-span-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-4">
            {values.map((v, i) => {
              const Icon = v.icon;
              return (
                <div
                  key={i}
                  className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-[0_8px_20px_rgba(0,0,0,0.02)] hover:shadow-lg hover:border-sky-200 transition-all duration-300 group"
                >
                  <div className="flex items-start gap-4">
                    <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 border ${v.badgeColor} group-hover:scale-105 transition-transform duration-200`}>
                      <Icon className="w-6 h-6" />
                    </div>
                    <div className="space-y-1">
                      <h4 className="text-base font-bold text-[#0B132B] font-outfit group-hover:text-sky-600 transition-colors">
                        {v.title}
                      </h4>
                      <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                        {v.desc}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

        </div>

      </div>
    </section>
  );
};
