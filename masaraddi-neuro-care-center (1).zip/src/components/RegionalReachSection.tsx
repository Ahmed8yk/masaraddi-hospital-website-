import React from 'react';
import { MapPin, Navigation, Bus, Train, Phone, CheckCircle2 } from 'lucide-react';
import { hospitalConfig } from '../config/hospitalConfig';

export const RegionalReachSection: React.FC = () => {
  const hubs = hospitalConfig.regionalReach.northKarnatakaHubs;
  const taluks = hospitalConfig.regionalReach.districtTaluks;

  return (
    <section className="py-24 bg-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-sky-50 border border-sky-200 text-sky-800 text-xs font-bold tracking-wide uppercase shadow-sm">
            <Navigation className="w-3.5 h-3.5 text-sky-600" />
            <span>Bagalkot & Surrounding Taluks</span>
          </div>
          
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#0B132B] tracking-tight font-outfit">
            Regional Neurological Care Hub
          </h2>
          
          <p className="text-base sm:text-lg text-slate-600 leading-relaxed">
            Patients travel from across North Karnataka districts to receive dedicated neurological consultation on Station Road, Bagalkot.
          </p>
        </div>

        {/* Nearby Cities & Taluks Grid */}
        <div className="mt-14 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3.5">
          {hubs.map((hub, i) => (
            <div
              key={i}
              className="bg-[#F8FAFC] rounded-2xl p-4 border border-slate-200/80 text-center hover:border-sky-300 hover:shadow-md transition-all group"
            >
              <MapPin className="w-5 h-5 text-sky-600 mx-auto group-hover:scale-110 transition-transform mb-2" />
              <h3 className="text-sm font-bold text-[#0B132B] font-outfit">{hub.name}</h3>
              <p className="text-xs text-slate-500 mt-0.5">{hub.distance}</p>
              <span className="text-[10px] text-sky-700 font-semibold mt-1 inline-block bg-sky-100/60 px-2 py-0.5 rounded-full">
                {hub.travelTime}
              </span>
            </div>
          ))}
        </div>

        {/* District Taluks Coverage List */}
        <div className="mt-8 bg-[#F8FAFC] rounded-3xl p-6 border border-slate-200/80 max-w-4xl mx-auto space-y-3">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block text-center">
            Bagalkot District Taluks & Localities Served:
          </span>
          <div className="flex flex-wrap items-center justify-center gap-2">
            {taluks.map((t, idx) => (
              <span
                key={idx}
                className="text-xs font-semibold bg-white border border-slate-200/90 text-slate-700 px-3 py-1 rounded-xl shadow-xs"
              >
                {t}
              </span>
            ))}
          </div>
        </div>

        {/* Transit & Accessibility Highlights */}
        <div className="mt-10 grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
          
          {/* Railway Station Accessibility */}
          <div className="bg-[#F8FAFC] rounded-3xl p-6 border border-slate-200/80 flex items-start gap-4 shadow-sm">
            <div className="w-12 h-12 rounded-2xl bg-sky-500/10 border border-sky-500/20 flex items-center justify-center shrink-0">
              <Train className="w-6 h-6 text-sky-600" />
            </div>
            <div className="space-y-1">
              <h4 className="text-base font-bold text-[#0B132B] font-outfit">
                Near Bagalkot Railway Station
              </h4>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                Located right along Station Road, providing quick access for patients arriving on regional passenger trains.
              </p>
            </div>
          </div>

          {/* Bus Stand Accessibility */}
          <div className="bg-[#F8FAFC] rounded-3xl p-6 border border-slate-200/80 flex items-start gap-4 shadow-sm">
            <div className="w-12 h-12 rounded-2xl bg-teal-500/10 border border-teal-500/20 flex items-center justify-center shrink-0">
              <Bus className="w-6 h-6 text-teal-600" />
            </div>
            <div className="space-y-1">
              <h4 className="text-base font-bold text-[#0B132B] font-outfit">
                Direct Bus Connectivity
              </h4>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                Seamless auto-rickshaw and local city transport connection from the Bagalkot Central KSRTC Bus Stand.
              </p>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
