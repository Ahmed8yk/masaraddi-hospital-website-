import React, { useState } from 'react';
import { StructuredData } from './components/StructuredData';
import { Navbar } from './components/Navbar';
import { HeroSlideshow } from './components/HeroSlideshow';
import { TrustStatsBar } from './components/TrustStatsBar';
import { AboutSection } from './components/AboutSection';
import { ServicesSection } from './components/ServicesSection';
import { DoctorsSection } from './components/DoctorsSection';
import { FacilitiesSection } from './components/FacilitiesSection';
import { PhotoGallery } from './components/PhotoGallery';
import { ReviewsSection } from './components/ReviewsSection';
import { RegionalReachSection } from './components/RegionalReachSection';
import { FaqSection } from './components/FaqSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { AIAssistantModal } from './components/AIAssistantModal';
import { FloatingAITrigger } from './components/FloatingAITrigger';
import { MobileStickyBar } from './components/MobileStickyBar';

export default function App() {
  const [isAIOpen, setIsAIOpen] = useState(false);

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-700 flex flex-col selection:bg-sky-500 selection:text-white font-sans">
      {/* Search Engine Structured Data (JSON-LD) */}
      <StructuredData />

      {/* Sticky Header Navigation */}
      <Navbar onOpenAI={() => setIsAIOpen(true)} />

      {/* Main Content Area */}
      <main className="flex-1">
        {/* 1. Hero Section with Continuous Hospital Photo Slideshow */}
        <HeroSlideshow onOpenAI={() => setIsAIOpen(true)} />

        {/* 2. Quick Trust Information & Verified Statistics Bar */}
        <TrustStatsBar />

        {/* 3. About Section: Compassionate Care. Focused Expertise. */}
        <AboutSection />

        {/* 4. Neurological Services Grid with Clinical Details */}
        <ServicesSection onOpenAI={() => setIsAIOpen(true)} />

        {/* 5. Specialized Medical Team & Doctor Profiles */}
        <DoctorsSection />

        {/* 6. Hospital Infrastructure & Facilities */}
        <FacilitiesSection />

        {/* 7. Responsive Photo Gallery with Lightbox */}
        <PhotoGallery />

        {/* 8. Verified Patient Reviews & Google Trust */}
        <ReviewsSection />

        {/* 9. Bagalkot & North Karnataka Regional Accessibility */}
        <RegionalReachSection />

        {/* 10. Frequently Asked Questions */}
        <FaqSection />

        {/* 11. Direct Contact & Google Maps Location */}
        <ContactSection />
      </main>

      {/* Hospital Footer */}
      <Footer />

      {/* Desktop Floating AI Assistant Trigger */}
      <FloatingAITrigger onOpen={() => setIsAIOpen(true)} />

      {/* Mobile Sticky Bottom Contact Bar (Call | WhatsApp | Ask AI) */}
      <MobileStickyBar onOpenAI={() => setIsAIOpen(true)} />

      {/* AI Hospital Information Assistant Drawer */}
      <AIAssistantModal isOpen={isAIOpen} onClose={() => setIsAIOpen(false)} />
    </div>
  );
}
