/**
 * Client-side AI and Chat Service
 * 
 * Safely interacts with the backend `/api/chat` route (which invokes Gemini API server-side).
 * Contains instant fallback handling if server response is delayed.
 */

import { hospitalConfig } from '../config/hospitalConfig';

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  source?: 'gemini' | 'knowledge-base' | 'fallback';
}

export async function sendChatMessage(
  message: string,
  history: { role: 'user' | 'assistant'; content: string }[] = []
): Promise<string> {
  try {
    const response = await fetch('/api/chat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        message,
        history,
      }),
    });

    if (!response.ok) {
      throw new Error(`Server returned ${response.status}`);
    }

    const data = await response.json();
    return data.reply;
  } catch (err) {
    console.warn('Backend chat API unavailable, utilizing verified local knowledge base fallback:', err);
    return getLocalKnowledgeFallback(message);
  }
}

/**
 * Intelligent local knowledge fallback matching hospitalConfig
 */
export function getLocalKnowledgeFallback(message: string): string {
  const lower = message.toLowerCase();

  if (
    lower.includes('emergency') ||
    lower.includes('chest pain') ||
    lower.includes('unconscious') ||
    lower.includes('heart attack') ||
    lower.includes('stroke') ||
    lower.includes('paralysis') ||
    lower.includes('critical')
  ) {
    return `🚨 **Emergency Clinical Notice**:\n\nIf you or a patient is experiencing emergency symptoms (such as sudden one-sided face/arm weakness, speech loss, or sudden unconsciousness), please visit the emergency hospital immediately or call Masaraddi Neuro Care Center directly at **${hospitalConfig.contact.phoneDisplay}**.\n\nTime is critical for acute neurological emergencies.`;
  }

  if (
    lower.includes('timing') ||
    lower.includes('hour') ||
    lower.includes('open') ||
    lower.includes('time') ||
    lower.includes('sunday')
  ) {
    return `🕒 **Hospital Working & Consultation Hours**:\n\n• **OPD Consultations**: ${hospitalConfig.contact.timings.opd}\n• **Sunday**: ${hospitalConfig.contact.timings.sunday}\n• **Inpatient & Emergency Support**: ${hospitalConfig.contact.timings.emergency}\n\nFeel free to call **${hospitalConfig.contact.phoneDisplay}** or WhatsApp us at **${hospitalConfig.contact.whatsappDisplay}** to confirm doctor availability prior to your visit.`;
  }

  if (
    lower.includes('address') ||
    lower.includes('location') ||
    lower.includes('where') ||
    lower.includes('directions') ||
    lower.includes('bagalkot') ||
    lower.includes('reach') ||
    lower.includes('near')
  ) {
    return `📍 **Hospital Location in Bagalkot**:\n\n**${hospitalConfig.hospitalName}**\n${hospitalConfig.contact.address.full}\n\n• Central Bagalkot, near BVVS Campus Area / Station Road\n• 5 minutes from Bagalkot Railway Station\n• Easily accessible from Old Bagalkot, Navanagar, and neighboring towns (Badami, Mudhol, Jamkhandi, Vijayapura, Gadag).`;
  }

  if (
    lower.includes('appointment') ||
    lower.includes('book') ||
    lower.includes('schedule') ||
    lower.includes('register') ||
    lower.includes('token')
  ) {
    return `ℹ️ **Appointment & Consultation Process**:\n\nMasaraddi Neuro Care Center does **not** require online appointment booking. Patients can directly walk in during OPD hours (Mon–Sat 9:00 AM – 7:30 PM).\n\nTo confirm current doctor availability or inquire beforehand, please **Call ${hospitalConfig.contact.phoneDisplay}** or message on **WhatsApp at ${hospitalConfig.contact.whatsappDisplay}**.`;
  }

  if (
    lower.includes('doctor') ||
    lower.includes('specialist') ||
    lower.includes('neurologist') ||
    lower.includes('staff') ||
    lower.includes('physician')
  ) {
    const docs = hospitalConfig.doctors
      .map(
        (d) =>
          `• **${d.name}**\n  *${d.qualification}*\n  *Specialty*: ${d.specialty} (${d.experience})\n  *OPD Hours*: ${d.timings}`
      )
      .join('\n\n');
    return `👨‍⚕️ **Doctors & Specialists at Masaraddi Neuro Care Center**:\n\n${docs}\n\nFor consultation availability, call **${hospitalConfig.contact.phoneDisplay}**.`;
  }

  if (
    lower.includes('service') ||
    lower.includes('headache') ||
    lower.includes('migraine') ||
    lower.includes('epilepsy') ||
    lower.includes('seizure') ||
    lower.includes('nerve') ||
    lower.includes('spine') ||
    lower.includes('parkinson') ||
    lower.includes('dizziness')
  ) {
    const sList = hospitalConfig.services
      .slice(0, 6)
      .map((s) => `• **${s.name}**: ${s.shortDescription}`)
      .join('\n\n');
    return `🧠 **Key Neurological Services Provided**:\n\n${sList}\n\n*Note: Our AI provides informational guidance only and cannot diagnose medical conditions. Please consult our neurologist for clinical evaluation.*`;
  }

  if (
    lower.includes('contact') ||
    lower.includes('phone') ||
    lower.includes('whatsapp') ||
    lower.includes('call') ||
    lower.includes('number') ||
    lower.includes('email')
  ) {
    return `📞 **Direct Contact Information**:\n\n• **Phone**: ${hospitalConfig.contact.phoneDisplay}\n• **WhatsApp**: ${hospitalConfig.contact.whatsappDisplay}\n• **Email**: ${hospitalConfig.contact.email}\n• **Address**: ${hospitalConfig.contact.address.full}\n\nYou can call us directly or chat with our hospital desk on WhatsApp!`;
  }

  if (
    lower.includes('review') ||
    lower.includes('rating') ||
    lower.includes('feedback') ||
    lower.includes('star')
  ) {
    return `⭐ **Hospital Rating & Patient Feedback**:\n\nMasaraddi Neuro Care Center is rated **${hospitalConfig.rating} ★** with **${hospitalConfig.reviewCount} Verified Reviews** on Google. We are committed to maintaining compassionate, professional, and patient-centered neurological care in Bagalkot.`;
  }

  return `Hello! Welcome to **Masaraddi Neuro Care Center** in Bagalkot, Karnataka.\n\nI can help you with:\n• Hospital OPD timings & emergency access\n• Neurological services & clinical scope\n• Doctor qualifications & consultation schedule\n• Location & directions in Bagalkot\n• Direct Phone (${hospitalConfig.contact.phoneDisplay}) & WhatsApp (${hospitalConfig.contact.whatsappDisplay}) contact\n\nHow may I assist you or your family today?`;
}
