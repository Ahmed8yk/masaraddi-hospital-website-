import React, { useState } from 'react';
import { 
  Activity, 
  Zap, 
  Brain, 
  HeartHandshake, 
  ShieldAlert, 
  Stethoscope, 
  CheckCircle2, 
  ArrowRight,
  Phone,
  MessageSquare,
  Sparkles,
  HelpCircle,
  FileText,
  HeartPulse,
  Bed
} from 'lucide-react';
import { hospitalConfig } from '../config/hospitalConfig';

interface ServicesSectionProps {
  onOpenAI: () => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({ onOpenAI }) => {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [selectedService, setSelectedService] = useState<typeof hospitalConfig.services[0] | null>(null);

  const categories = [
    { id: 'all', name: 'All Services' },
    { id: 'Outpatient Services', name: 'Outpatient' },
    { id: 'Specialized Clinic', name: 'Migraine & Headache' },
    { id: 'Acute & Post-Acute Care', name: 'Stroke & Recovery' },
    { id: 'Chronic Disease Care', name: 'Epilepsy & Seizures' },
    { id: 'Inpatient Care', name: 'Inpatient Care' },
  ];

  const filteredServices = activeCategory === 'all'
    ? hospitalConfig.services
    : hospitalConfig.services.filter(s => s.category === activeCategory);

  const getServiceIcon = (iconName: string) => {
    switch (iconName) {
      case 'Zap': return Zap;
      case 'Activity': return Activity;
      case 'Brain': return Brain;
      case 'ShieldAlert': return ShieldAlert;
      case 'Stethoscope': return Stethoscope;
      case 'FileText': return FileText;
      case 'HeartPulse': return HeartPulse;
      case 'Bed': return Bed;
      default: return HeartHandshake;
    }
  };

  return (
    <section id="services" className="py-24 bg-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-sky-50 border border-sky-200 text-sky-800 text-xs font-bold tracking-wide uppercase shadow-sm">
            <Activity className="w-3.5 h-3.5 text-sky-600" />
            <span>Clinical Treatments & Diagnostics</span>
          </div>
          
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#0B132B] tracking-tight font-outfit">
            Comprehensive Neurological Medical Services
          </h2>
          
          <p className="text-base sm:text-lg text-slate-600 leading-relaxed">
            From emergency stroke stabilization and chronic migraine management to seizure control and inpatient neuro monitoring.
          </p>
        </div>

        {/* Category Filter Tabs */}
        <div className="mt-10 flex flex-wrap items-center justify-center gap-2">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-4 py-2 rounded-2xl text-xs sm:text-sm font-bold transition-all duration-200 ${
                activeCategory === cat.id
                  ? 'bg-[#0B132B] text-white shadow-md shadow-slate-900/20 scale-[1.02]'
                  : 'bg-slate-100/80 hover:bg-slate-200/80 text-slate-600'
              }`}
            >
              {cat.name}
            </button>
          ))}
        </div>

        {/* Services Grid */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {filteredServices.map((service) => {
            const Icon = getServiceIcon(service.icon);
            return (
              <div
                key={service.id}
                className="bg-[#F8FAFC] rounded-3xl p-7 border border-slate-200/80 hover:border-sky-300 hover:shadow-xl hover:shadow-sky-500/5 transition-all duration-300 flex flex-col justify-between group"
              >
                <div className="space-y-4">
                  {/* Top Badge & Icon */}
                  <div className="flex items-center justify-between">
                    <div className="w-12 h-12 rounded-2xl bg-white text-sky-600 border border-slate-200/80 shadow-sm flex items-center justify-center group-hover:bg-sky-600 group-hover:text-white group-hover:border-sky-600 transition-all duration-300">
                      <Icon className="w-6 h-6" />
                    </div>
                    <span className="text-[11px] font-bold text-sky-700 bg-sky-100/70 border border-sky-200/60 px-3 py-1 rounded-full">
                      {service.category}
                    </span>
                  </div>

                  {/* Title & Description */}
                  <div>
                    <h3 className="text-lg sm:text-xl font-bold text-[#0B132B] font-outfit group-hover:text-sky-600 transition-colors">
                      {service.name}
                    </h3>
                    <p className="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed">
                      {service.shortDescription}
                    </p>
                  </div>

                  {/* Features List */}
                  <div className="pt-2 space-y-1.5">
                    {service.whatWeOffer.slice(0, 3).map((feat, idx) => (
                      <div key={idx} className="flex items-center gap-2 text-xs text-slate-700">
                        <CheckCircle2 className="w-3.5 h-3.5 text-sky-600 shrink-0" />
                        <span>{feat}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Card Action Footnotes */}
                <div className="pt-6 mt-6 border-t border-slate-200/60 flex items-center justify-between">
                  <button
                    onClick={() => setSelectedService(service)}
                    className="inline-flex items-center gap-1.5 text-xs font-bold text-sky-600 hover:text-sky-700 group-hover:translate-x-0.5 transition-transform"
                  >
                    <span>View Treatment Details</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>

                  <a
                    href={`tel:${hospitalConfig.contact.phone}`}
                    className="p-2 rounded-xl bg-white hover:bg-sky-50 text-slate-700 hover:text-sky-600 border border-slate-200/80 shadow-sm transition-colors"
                    title="Inquire by phone"
                  >
                    <Phone className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
            );
          })}
        </div>

        {/* AI Symptom Guidance Banner */}
        <div className="mt-16 rounded-3xl bg-gradient-to-r from-[#080E1A] via-[#0B132B] to-[#1E293B] p-8 sm:p-10 text-white shadow-xl flex flex-col md:flex-row items-center justify-between gap-6 border border-slate-800">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-sky-500/20 text-sky-300 text-xs font-bold border border-sky-400/30">
              <Sparkles className="w-3.5 h-3.5 text-sky-400" />
              <span>Interactive Patient Guidance</span>
            </div>
            <h3 className="text-xl sm:text-2xl font-bold font-outfit text-white">
              Not sure which neurological specialist consultation you need?
            </h3>
            <p className="text-xs sm:text-sm text-slate-300">
              Ask our interactive AI clinical assistant about common neurological symptoms, visiting hours, or department options at Masaraddi Neuro Care Center.
            </p>
          </div>

          <button
            onClick={onOpenAI}
            className="shrink-0 px-6 py-3.5 rounded-2xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 hover:to-blue-500 text-white font-bold text-xs sm:text-sm shadow-lg shadow-sky-600/30 hover:scale-[1.02] active:scale-95 transition-all flex items-center gap-2"
          >
            <Sparkles className="w-4 h-4" />
            <span>Ask Symptoms Guidance</span>
          </button>
        </div>

      </div>

      {/* Service Detail Modal */}
      {selectedService && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 space-y-6 shadow-2xl border border-slate-100 max-h-[90vh] overflow-y-auto">
            <div className="flex items-start justify-between gap-4">
              <div className="space-y-1">
                <span className="text-xs font-bold text-sky-600 uppercase tracking-wider">
                  {selectedService.category}
                </span>
                <h3 className="text-xl sm:text-2xl font-bold text-[#0B132B] font-outfit">
                  {selectedService.name}
                </h3>
              </div>
              <button
                onClick={() => setSelectedService(null)}
                className="p-1.5 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 transition-colors"
              >
                ✕
              </button>
            </div>

            <p className="text-sm text-slate-600 leading-relaxed">
              {selectedService.detailedDescription}
            </p>

            <div className="space-y-2">
              <h4 className="text-xs font-bold text-[#0B132B] uppercase tracking-wider">
                Key Diagnostic & Care Components:
              </h4>
              <ul className="space-y-2">
                {selectedService.whatWeOffer.map((feat, i) => (
                  <li key={i} className="flex items-start gap-2 text-xs sm:text-sm text-slate-700">
                    <CheckCircle2 className="w-4 h-4 text-sky-600 shrink-0 mt-0.5" />
                    <span>{feat}</span>
                  </li>
                ))}
              </ul>
            </div>

            {selectedService.commonSymptoms && selectedService.commonSymptoms.length > 0 && (
              <div className="space-y-2">
                <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                  Common Evaluated Symptoms:
                </h4>
                <div className="flex flex-wrap gap-1.5">
                  {selectedService.commonSymptoms.map((sym, i) => (
                    <span key={i} className="text-xs bg-slate-100 text-slate-700 px-2.5 py-1 rounded-xl">
                      {sym}
                    </span>
                  ))}
                </div>
              </div>
            )}

            <div className="p-4 rounded-2xl bg-sky-50 border border-sky-100 text-xs text-slate-700 space-y-1">
              <span className="font-bold text-[#0B132B] block">OPD Consultation & Booking:</span>
              <p>Consultations are available on Station Road in Bagalkot. Please bring previous MRI/CT scans or EEG reports if available.</p>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2">
              <a
                href={`tel:${hospitalConfig.contact.phone}`}
                className="flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 text-white font-bold text-xs shadow-md shadow-sky-600/30 transition-all hover:scale-[1.02]"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>Call Hospital</span>
              </a>
              <button
                onClick={() => setSelectedService(null)}
                className="py-3 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
