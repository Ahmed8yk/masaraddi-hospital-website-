import React, { useState } from 'react';
import { 
  Phone, 
  MapPin, 
  Clock, 
  Navigation, 
  MessageSquare, 
  Mail, 
  CheckCircle2, 
  Copy,
  Check,
  Send
} from 'lucide-react';
import { hospitalConfig } from '../config/hospitalConfig';

export const ContactSection: React.FC = () => {
  const [copied, setCopied] = useState(false);
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    department: 'General Neuro Consultation',
    message: '',
  });

  const handleCopyAddress = () => {
    navigator.clipboard.writeText(
      hospitalConfig.contact.address.full
    );
    setCopied(true);
    setTimeout(() => setCopied(false), 3000);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormSubmitted(true);
  };

  return (
    <section id="contact" className="py-24 bg-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-sky-50 border border-sky-200 text-sky-800 text-xs font-bold tracking-wide uppercase shadow-sm">
            <MapPin className="w-3.5 h-3.5 text-sky-600" />
            <span>Hospital Contact & Directions</span>
          </div>
          
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#0B132B] tracking-tight font-outfit">
            Visit or Connect with Masaraddi Neuro Care Center
          </h2>
          
          <p className="text-base sm:text-lg text-slate-600 leading-relaxed">
            Located on Station Road in Bagalkot, easily accessible from the Bagalkot Railway Station and Central Bus Stand.
          </p>
        </div>

        {/* Contact Grid */}
        <div className="mt-16 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Column: Direct Contact Cards & Address */}
          <div className="lg:col-span-5 space-y-5">
            
            {/* Address Card */}
            <div className="bg-[#F8FAFC] rounded-3xl p-7 border border-slate-200/80 space-y-4 shadow-sm">
              <div className="flex items-start gap-3.5">
                <div className="w-12 h-12 rounded-2xl bg-white text-sky-600 flex items-center justify-center shrink-0 border border-slate-200 shadow-sm">
                  <MapPin className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-[#0B132B] font-outfit">
                    Hospital Location
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-600 mt-1 leading-relaxed">
                    {hospitalConfig.contact.address.street}
                    <br />
                    {hospitalConfig.contact.address.city}, {hospitalConfig.contact.address.state} - {hospitalConfig.contact.address.postalCode}
                  </p>
                  <p className="text-xs text-sky-700 font-semibold mt-1.5">
                    {hospitalConfig.contact.address.landmark}
                  </p>
                </div>
              </div>

              {/* Action Buttons for Address */}
              <div className="pt-2 flex flex-wrap gap-2.5">
                <a
                  href={hospitalConfig.contact.googleMapsDirectionsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 inline-flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 hover:to-blue-500 text-white font-bold text-xs shadow-md shadow-sky-600/20 transition-all hover:scale-[1.01]"
                >
                  <Navigation className="w-3.5 h-3.5" />
                  <span>Get GPS Directions</span>
                </a>
                <button
                  onClick={handleCopyAddress}
                  className="inline-flex items-center justify-center gap-1.5 py-3 px-4 rounded-xl bg-white hover:bg-slate-100 text-[#0B132B] font-semibold text-xs border border-slate-200 shadow-xs transition-all"
                  title="Copy full address"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
            </div>

            {/* Direct Calling & WhatsApp Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Phone Card */}
              <a
                href={`tel:${hospitalConfig.contact.phone}`}
                className="bg-[#F8FAFC] hover:bg-sky-50/60 p-5 rounded-3xl border border-slate-200/80 hover:border-sky-300 transition-all shadow-sm group block"
              >
                <div className="w-10 h-10 rounded-2xl bg-white text-sky-600 flex items-center justify-center shrink-0 border border-slate-200 shadow-xs mb-3 group-hover:scale-105 transition-transform">
                  <Phone className="w-5 h-5" />
                </div>
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Hospital Desk</h4>
                <p className="text-sm font-bold text-[#0B132B] group-hover:text-sky-600 transition-colors mt-0.5">
                  {hospitalConfig.contact.phoneDisplay}
                </p>
                <span className="text-[11px] text-sky-600 font-semibold mt-1 inline-block">
                  Click to call directly →
                </span>
              </a>

              {/* WhatsApp Card */}
              <a
                href={`https://wa.me/${hospitalConfig.contact.whatsappNumber}?text=${encodeURIComponent(
                  hospitalConfig.contact.whatsappMessage
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="bg-[#F8FAFC] hover:bg-emerald-50/60 p-5 rounded-3xl border border-slate-200/80 hover:border-emerald-300 transition-all shadow-sm group block"
              >
                <div className="w-10 h-10 rounded-2xl bg-white text-emerald-600 flex items-center justify-center shrink-0 border border-slate-200 shadow-xs mb-3 group-hover:scale-105 transition-transform">
                  <MessageSquare className="w-5 h-5" />
                </div>
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">WhatsApp Desk</h4>
                <p className="text-sm font-bold text-[#0B132B] group-hover:text-emerald-600 transition-colors mt-0.5">
                  Instant Support
                </p>
                <span className="text-[11px] text-emerald-600 font-semibold mt-1 inline-block">
                  Message on WhatsApp →
                </span>
              </a>
            </div>

            {/* Timings Card */}
            <div className="bg-[#F8FAFC] rounded-3xl p-6 border border-slate-200/80 space-y-2.5 text-xs shadow-sm">
              <div className="flex items-center gap-2 text-[#0B132B] font-bold">
                <Clock className="w-4 h-4 text-sky-600" />
                <span>Hospital Operating Hours</span>
              </div>
              <div className="space-y-1.5 text-slate-600 pl-6">
                <div className="flex justify-between">
                  <span>Outpatient (OPD) Consultations:</span>
                  <span className="font-semibold text-[#0B132B]">{hospitalConfig.contact.timings.opd}</span>
                </div>
                <div className="flex justify-between">
                  <span>Sunday Consultations:</span>
                  <span className="font-semibold text-[#0B132B]">{hospitalConfig.contact.timings.sunday}</span>
                </div>
                <div className="flex justify-between">
                  <span>Emergency / Inpatient:</span>
                  <span className="font-semibold text-emerald-600">{hospitalConfig.contact.timings.emergency}</span>
                </div>
              </div>
            </div>

          </div>

          {/* Right Column: Google Maps Embed & Quick Inquiry Form */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* Interactive Google Maps Frame */}
            <div className="bg-[#F8FAFC] rounded-3xl p-4 sm:p-5 border border-slate-200/80 shadow-sm overflow-hidden space-y-3">
              <div className="flex items-center justify-between px-2">
                <div className="flex items-center gap-2 text-xs font-bold text-[#0B132B]">
                  <MapPin className="w-4 h-4 text-sky-600" />
                  <span>Google Maps Location — Station Road, Bagalkot</span>
                </div>
                <a
                  href={hospitalConfig.contact.googleMapsDirectionsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs text-sky-600 hover:underline font-bold"
                >
                  Open in Maps App
                </a>
              </div>
              
              <div className="w-full h-72 sm:h-80 rounded-2xl overflow-hidden border border-slate-200 relative bg-slate-200">
                <iframe
                  title="Masaraddi Neuro Care Center Location Map"
                  src={hospitalConfig.contact.googleMapsEmbedUrl}
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  className="w-full h-full"
                />
              </div>
            </div>

            {/* Quick Consultation Inquiry Form */}
            <div className="bg-white rounded-3xl p-7 sm:p-8 border border-slate-200/80 shadow-[0_10px_30px_rgba(0,0,0,0.03)] space-y-4">
              <h3 className="text-xl font-bold text-[#0B132B] font-outfit">
                Request OPD Consultation Information
              </h3>
              <p className="text-xs text-slate-500">
                Leave your details and our Bagalkot hospital reception will get back to you with doctor slots and timings.
              </p>

              {formSubmitted ? (
                <div className="p-5 rounded-2xl bg-emerald-50 border border-emerald-200 text-center space-y-2 animate-in fade-in">
                  <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto" />
                  <h4 className="text-sm font-bold text-[#0B132B]">Inquiry Received!</h4>
                  <p className="text-xs text-slate-600">
                    Thank you. Our hospital front desk on Station Road will contact you shortly at {formData.phone}. For immediate assistance, please call us directly.
                  </p>
                  <button
                    onClick={() => {
                      setFormSubmitted(false);
                      setFormData({ name: '', phone: '', department: 'General Neuro Consultation', message: '' });
                    }}
                    className="mt-2 text-xs font-bold text-sky-600 hover:underline"
                  >
                    Submit another inquiry
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-[#0B132B] mb-1.5">
                        Patient / Visitor Name *
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="Enter full name"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        className="w-full px-4 py-2.5 rounded-xl border border-slate-300 text-xs sm:text-sm text-[#0B132B] focus:outline-none focus:ring-2 focus:ring-sky-500 bg-white"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-[#0B132B] mb-1.5">
                        Contact Phone Number *
                      </label>
                      <input
                        type="tel"
                        required
                        placeholder="e.g. +91 98765 43210"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        className="w-full px-4 py-2.5 rounded-xl border border-slate-300 text-xs sm:text-sm text-[#0B132B] focus:outline-none focus:ring-2 focus:ring-sky-500 bg-white"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-[#0B132B] mb-1.5">
                        Consultation Department
                      </label>
                      <select
                        value={formData.department}
                        onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                        className="w-full px-4 py-2.5 rounded-xl border border-slate-300 text-xs sm:text-sm text-[#0B132B] focus:outline-none focus:ring-2 focus:ring-sky-500 bg-white"
                      >
                        <option value="General Neuro Consultation">General Neuro Consultation</option>
                        <option value="Epilepsy & Seizure Care">Epilepsy & Seizure Care</option>
                        <option value="Stroke Recovery Management">Stroke Recovery Management</option>
                        <option value="Headache & Migraine Clinic">Headache & Migraine Clinic</option>
                        <option value="Spine & Nerve Evaluation">Spine & Nerve Evaluation</option>
                        <option value="Inpatient Admission Inquiry">Inpatient Admission Inquiry</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-[#0B132B] mb-1.5">
                        Patient City / Taluk
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. Bagalkot, Mudhol, Badami"
                        className="w-full px-4 py-2.5 rounded-xl border border-slate-300 text-xs sm:text-sm text-[#0B132B] focus:outline-none focus:ring-2 focus:ring-sky-500 bg-white"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-[#0B132B] mb-1.5">
                      Brief Message or Symptoms (Optional)
                    </label>
                    <textarea
                      rows={2}
                      placeholder="Mention any symptoms, past reports, or preferred consultation day..."
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      className="w-full px-4 py-2.5 rounded-xl border border-slate-300 text-xs sm:text-sm text-[#0B132B] focus:outline-none focus:ring-2 focus:ring-sky-500 bg-white"
                    />
                  </div>

                  {/* Submit Button */}
                  <button
                    type="submit"
                    className="w-full py-3.5 rounded-xl bg-gradient-to-r from-sky-500 via-sky-600 to-blue-600 hover:from-sky-400 hover:to-blue-500 text-white font-bold text-sm shadow-md shadow-sky-600/25 transition-all hover:scale-[1.01] active:scale-98 flex items-center justify-center gap-2"
                  >
                    <Send className="w-4 h-4" />
                    <span>Submit OPD Inquiry to Hospital</span>
                  </button>
                </form>
              )}
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
