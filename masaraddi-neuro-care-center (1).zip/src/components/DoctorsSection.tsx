import React from 'react';
import { Stethoscope, Award, Calendar, Phone, CheckCircle2, Clock, MapPin, UserCheck, ShieldCheck } from 'lucide-react';
import { hospitalConfig } from '../config/hospitalConfig';

export const DoctorsSection: React.FC = () => {
  return (
    <section id="doctors" className="py-24 bg-[#F8FAFC] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-sky-100/80 border border-sky-200 text-sky-800 text-xs font-bold tracking-wide uppercase shadow-sm">
            <UserCheck className="w-3.5 h-3.5 text-sky-600" />
            <span>Clinical Medical Leadership</span>
          </div>
          
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#0B132B] tracking-tight font-outfit">
            Qualified Doctors & Compassionate Neuro Care Team
          </h2>
          
          <p className="text-base sm:text-lg text-slate-600 leading-relaxed">
            Our medical specialists and nursing staff bring dedicated focus, clinical diagnostics, and continuous patient monitoring to Bagalkot.
          </p>
        </div>

        {/* Doctor Profiles Grid */}
        <div className="mt-16 grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {hospitalConfig.doctors.map((doc) => (
            <div
              key={doc.id}
              className="bg-white rounded-3xl p-7 sm:p-8 border border-slate-200/80 shadow-[0_10px_30px_rgba(0,0,0,0.03)] hover:shadow-xl hover:border-sky-200 transition-all duration-300 flex flex-col justify-between"
            >
              <div className="space-y-5">
                {/* Doctor Avatar / Image & Credentials Header */}
                <div className="flex items-start gap-4 sm:gap-5">
                  <div className="relative w-20 h-20 sm:w-24 sm:h-24 rounded-2xl overflow-hidden border-2 border-sky-100 shadow-md shrink-0 bg-slate-100">
                    <img
                      src={doc.image}
                      alt={doc.name}
                      className="w-full h-full object-cover object-top"
                    />
                    <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/60 to-transparent p-1">
                      <span className="text-[9px] text-white font-bold block text-center">MD / Neuro</span>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <span className="text-[11px] font-bold text-sky-700 bg-sky-50 border border-sky-100 px-2.5 py-0.5 rounded-full inline-block">
                      {doc.specialty}
                    </span>
                    <h3 className="text-xl sm:text-2xl font-bold text-[#0B132B] font-outfit">
                      {doc.name}
                    </h3>
                    <p className="text-xs sm:text-sm font-semibold text-slate-700">
                      {doc.qualification}
                    </p>
                    <div className="flex items-center gap-1.5 text-xs text-amber-600 font-medium">
                      <Award className="w-3.5 h-3.5 text-amber-500" />
                      <span>{doc.experience}</span>
                    </div>
                  </div>
                </div>

                {/* Bio & Clinical Focus */}
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  {doc.bio}
                </p>

                {/* Departments Chips */}
                <div className="space-y-2">
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                    Specialized Expertise:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {doc.departments.map((dept, i) => (
                      <span
                        key={i}
                        className="text-xs font-semibold bg-slate-100 text-slate-700 px-2.5 py-1 rounded-xl"
                      >
                        {dept}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Consultation Availability */}
                <div className="p-3.5 rounded-2xl bg-sky-50/70 border border-sky-100 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2 text-slate-700 font-medium">
                    <Clock className="w-4 h-4 text-sky-600" />
                    <span>OPD Consultation:</span>
                  </div>
                  <span className="font-bold text-[#0B132B]">{doc.timings}</span>
                </div>
              </div>

              {/* Action Button */}
              <div className="pt-6 mt-6 border-t border-slate-100">
                <a
                  href={`tel:${hospitalConfig.contact.phone}`}
                  className="w-full inline-flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 hover:to-blue-500 text-white font-bold text-xs shadow-md shadow-sky-600/20 transition-all hover:scale-[1.01]"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>Request OPD Slot with Doctor</span>
                </a>
              </div>
            </div>
          ))}
        </div>

        {/* Nursing & Inpatient Support Staff Guarantee Card */}
        <div className="mt-12 bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-sm max-w-5xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-6 h-6 text-emerald-600" />
            </div>
            <div className="space-y-0.5">
              <h4 className="text-base font-bold text-[#0B132B] font-outfit">
                24/7 Nursing & Inpatient Monitoring
              </h4>
              <p className="text-xs sm:text-sm text-slate-600">
                Trained nursing caregivers and pharmacy staff assist admitted neurology patients day and night.
              </p>
            </div>
          </div>

          <div className="shrink-0 flex items-center gap-2 text-xs font-bold text-sky-700 bg-sky-50 px-4 py-2 rounded-xl border border-sky-100">
            <span>Station Road Campus</span>
          </div>
        </div>

      </div>
    </section>
  );
};
