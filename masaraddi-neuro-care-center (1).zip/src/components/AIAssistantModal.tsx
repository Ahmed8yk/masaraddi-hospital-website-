import React, { useState, useRef, useEffect } from 'react';
import { 
  X, 
  Send, 
  Sparkles, 
  Phone, 
  MessageSquare, 
  Bot, 
  User, 
  AlertCircle
} from 'lucide-react';
import { hospitalConfig } from '../config/hospitalConfig';
import { sendChatMessage, ChatMessage } from '../services/aiService';

interface AIAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AIAssistantModal: React.FC<AIAssistantModalProps> = ({ isOpen, onClose }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'init-1',
      role: 'assistant',
      content: `Hello! 👋 Welcome to **Masaraddi Neuro Care Center**.\n\nI'm here to assist you with information about our hospital, neurological services, doctors, location on Station Road in Bagalkot, timings, and general patient inquiries.\n\nHow can I assist you today?`,
      timestamp: new Date(),
    },
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const inputRef = useRef<HTMLInputElement | null>(null);

  const quickChips = [
    { label: 'About Hospital', query: 'Tell me about Masaraddi Neuro Care Center' },
    { label: 'Neurology Services', query: 'What neurological services and treatments do you offer?' },
    { label: 'Doctors & Specialists', query: 'Who are the doctors and neurologists at the hospital?' },
    { label: 'Hospital Timings & OPD', query: 'What are the hospital OPD timings and consultation hours?' },
    { label: 'Location & Directions', query: 'Where is the hospital located in Bagalkot and how to reach?' },
    { label: 'Appointment Process', query: 'How do I book an appointment or visit the hospital?' },
    { label: 'Talk to Hospital on WhatsApp', isAction: 'whatsapp' },
    { label: 'Call Hospital Desk', isAction: 'phone' },
  ];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
      setTimeout(() => inputRef.current?.focus(), 150);
    }
  }, [isOpen, messages]);

  const handleSendMessage = async (textToSend?: string) => {
    const query = textToSend || inputValue.trim();
    if (!query || isLoading) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: query,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setInputValue('');
    setIsLoading(true);

    try {
      const historyPayload = messages.map((m) => ({
        role: m.role,
        content: m.content,
      }));

      const reply = await sendChatMessage(query, historyPayload);

      const assistantMsg: ChatMessage = {
        id: `assistant-${Date.now()}`,
        role: 'assistant',
        content: reply,
        timestamp: new Date(),
      };

      setMessages((prev) => [...prev, assistantMsg]);
    } catch (err) {
      const fallbackMsg: ChatMessage = {
        id: `assistant-${Date.now()}`,
        role: 'assistant',
        content: `I'm here to assist you with hospital information. Please call our hospital desk at **${hospitalConfig.contact.phoneDisplay}** or message on WhatsApp at **${hospitalConfig.contact.whatsappDisplay}** for immediate assistance.`,
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, fallbackMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleChipClick = (chip: typeof quickChips[0]) => {
    if (chip.isAction === 'whatsapp') {
      window.open(
        `https://wa.me/${hospitalConfig.contact.whatsappNumber}?text=${encodeURIComponent(
          hospitalConfig.contact.whatsappMessage
        )}`,
        '_blank'
      );
      return;
    }
    if (chip.isAction === 'phone') {
      window.location.href = `tel:${hospitalConfig.contact.phone}`;
      return;
    }
    if (chip.query) {
      handleSendMessage(chip.query);
    }
  };

  const parseBold = (text: string) => {
    const parts = text.split(/(\*\*.*?\*\*)/g);
    return parts.map((part, i) => {
      if (part.startsWith('**') && part.endsWith('**')) {
        return <strong key={i} className="font-bold text-[#0B132B]">{part.slice(2, -2)}</strong>;
      }
      return part;
    });
  };

  const renderFormattedContent = (content: string) => {
    return content.split('\n').map((line, idx) => {
      if (line.startsWith('• ') || line.startsWith('- ') || line.startsWith('* ')) {
        const bulletText = line.substring(2);
        return (
          <div key={idx} className="flex items-start gap-1.5 my-1 pl-1">
            <span className="text-sky-600 font-bold">•</span>
            <span>{parseBold(bulletText)}</span>
          </div>
        );
      }
      if (line.trim() === '') {
        return <div key={idx} className="h-2" />;
      }
      return (
        <p key={idx} className="my-1">
          {parseBold(line)}
        </p>
      );
    });
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/60 backdrop-blur-sm flex justify-end animate-in fade-in duration-200">
      
      {/* Assistant Drawer */}
      <div className="w-full max-w-lg bg-white h-full shadow-2xl flex flex-col justify-between border-l border-slate-200 animate-in slide-in-from-right duration-300">
        
        {/* Header */}
        <div className="p-4 sm:p-5 bg-[#080E1A] text-white flex items-center justify-between border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-sky-500 to-blue-600 flex items-center justify-center text-white shadow-md">
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-sm sm:text-base font-outfit text-white">
                  Masaraddi AI Assistant
                </h3>
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              </div>
              <p className="text-[11px] text-slate-400">
                Hospital Information & Patient Guidance
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            aria-label="Close Assistant"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Safety Banner */}
        <div className="px-4 py-2 bg-sky-50 border-b border-sky-100 text-[11px] text-slate-700 flex items-center gap-2 shrink-0">
          <AlertCircle className="w-3.5 h-3.5 text-sky-600 shrink-0" />
          <span>General hospital information only. Not a substitute for medical diagnosis.</span>
        </div>

        {/* Messages List Area */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4 bg-[#F8FAFC]">
          {messages.map((msg) => {
            const isUser = msg.role === 'user';
            return (
              <div
                key={msg.id}
                className={`flex gap-3 ${isUser ? 'justify-end' : 'justify-start'}`}
              >
                {!isUser && (
                  <div className="w-7 h-7 rounded-lg bg-sky-600 text-white flex items-center justify-center shrink-0 mt-1 shadow-sm">
                    <Bot className="w-4 h-4 text-white" />
                  </div>
                )}

                <div
                  className={`max-w-[85%] rounded-2xl px-4 py-3 text-xs sm:text-sm leading-relaxed shadow-xs ${
                    isUser
                      ? 'bg-[#0B132B] text-white rounded-tr-none'
                      : 'bg-white text-slate-700 border border-slate-200/90 rounded-tl-none'
                  }`}
                >
                  {renderFormattedContent(msg.content)}

                  {/* Direct Contact Action Row inside AI messages */}
                  {!isUser && msg.id !== 'init-1' && (
                    <div className="mt-3 pt-2.5 border-t border-slate-100 flex flex-wrap items-center gap-2">
                      <a
                        href={`tel:${hospitalConfig.contact.phone}`}
                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-sky-50 text-sky-700 font-bold text-[11px] hover:bg-sky-100 border border-sky-200"
                      >
                        <Phone className="w-3 h-3" />
                        <span>Call Hospital</span>
                      </a>
                      <a
                        href={`https://wa.me/${hospitalConfig.contact.whatsappNumber}?text=${encodeURIComponent(
                          hospitalConfig.contact.whatsappMessage
                        )}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-700 font-bold text-[11px] hover:bg-emerald-100 border border-emerald-200"
                      >
                        <MessageSquare className="w-3 h-3" />
                        <span>WhatsApp Desk</span>
                      </a>
                    </div>
                  )}

                  <div className="mt-1 text-[10px] text-slate-400 text-right">
                    {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </div>
                </div>

                {isUser && (
                  <div className="w-7 h-7 rounded-lg bg-[#0B132B] text-white flex items-center justify-center shrink-0 mt-1 shadow-sm">
                    <User className="w-4 h-4 text-sky-400" />
                  </div>
                )}
              </div>
            );
          })}

          {isLoading && (
            <div className="flex gap-3 justify-start">
              <div className="w-7 h-7 rounded-lg bg-sky-600 text-white flex items-center justify-center shrink-0 mt-1 shadow-sm animate-pulse">
                <Bot className="w-4 h-4" />
              </div>
              <div className="bg-white rounded-2xl rounded-tl-none px-4 py-3 border border-slate-200 shadow-xs flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-sky-600 animate-bounce" />
                <span className="w-2 h-2 rounded-full bg-sky-600 animate-bounce [animation-delay:0.2s]" />
                <span className="w-2 h-2 rounded-full bg-sky-600 animate-bounce [animation-delay:0.4s]" />
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Quick Action Chips Strip */}
        <div className="p-3 bg-white border-t border-slate-200 shrink-0">
          <p className="text-[11px] font-semibold text-slate-700 mb-2 px-1">
            Quick Inquiries:
          </p>
          <div className="flex gap-1.5 overflow-x-auto pb-1.5 no-scrollbar scroll-smooth">
            {quickChips.map((chip, idx) => (
              <button
                key={idx}
                onClick={() => handleChipClick(chip)}
                className={`whitespace-nowrap px-3 py-1.5 rounded-full text-xs font-semibold border transition-colors shrink-0 ${
                  chip.isAction === 'whatsapp'
                    ? 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100'
                    : chip.isAction === 'phone'
                    ? 'bg-sky-50 text-sky-700 border-sky-200 hover:bg-sky-100'
                    : 'bg-slate-100 text-slate-700 border-slate-200 hover:bg-slate-200'
                }`}
              >
                {chip.label}
              </button>
            ))}
          </div>
        </div>

        {/* Input Form Bar */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}
          className="p-4 bg-white border-t border-slate-200 shrink-0 flex items-center gap-2"
        >
          <input
            ref={inputRef}
            type="text"
            placeholder="Type your question here (e.g. OPD hours, doctor timings)..."
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            disabled={isLoading}
            className="flex-1 px-4 py-2.5 rounded-xl border border-slate-300 bg-[#F8FAFC] text-xs sm:text-sm text-[#0B132B] focus:outline-none focus:ring-2 focus:ring-sky-500 focus:bg-white transition-colors"
          />
          <button
            type="submit"
            disabled={!inputValue.trim() || isLoading}
            className="p-2.5 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 hover:to-blue-500 disabled:opacity-40 disabled:cursor-not-allowed text-white shadow-sm transition-all"
            aria-label="Send Message"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>

      </div>
    </div>
  );
};
