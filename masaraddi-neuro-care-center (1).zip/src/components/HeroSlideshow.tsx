import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Phone, MessageSquare, ChevronLeft, ChevronRight, Pause, Play, Star, MapPin, Sparkles, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { hospitalConfig } from '../config/hospitalConfig';

interface HeroSlideshowProps {
  onOpenAI: () => void;
}

export const HeroSlideshow: React.FC<HeroSlideshowProps> = ({ onOpenAI }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const touchStartX = useRef<number | null>(null);
  const touchEndX = useRef<number | null>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const slides = hospitalConfig.heroSlides;

  const nextSlide = useCallback(() => {
    setCurrentIndex((prev) => (prev === slides.length - 1 ? 0 : prev + 1));
  }, [slides.length]);

  const prevSlide = useCallback(() => {
    setCurrentIndex((prev) => (prev === 0 ? slides.length - 1 : prev - 1));
  }, [slides.length]);

  const goToSlide = (index: number) => {
    setCurrentIndex(index);
  };

  // Auto transition
  useEffect(() => {
    if (isPlaying) {
      timerRef.current = setInterval(() => {
        nextSlide();
      }, 4800);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isPlaying, nextSlide]);

  // Touch gesture handling
  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.targetTouches[0].clientX;
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    touchEndX.current = e.targetTouches[0].clientX;
  };

  const handleTouchEnd = () => {
    if (!touchStartX.current || !touchEndX.current) return;
    const distance = touchStartX.current - touchEndX.current;
    const minSwipeDistance = 50;

    if (distance > minSwipeDistance) {
      nextSlide();
    } else if (distance < -minSwipeDistance) {
      prevSlide();
    }
    touchStartX.current = null;
    touchEndX.current = null;
  };

  return (
    <section
      id="home"
      className="relative min-h-[92vh] md:min-h-screen flex items-center justify-center overflow-hidden bg-[#080E1A] pt-24 pb-16"
      onMouseEnter={() => setIsPlaying(false)}
      onMouseLeave={() => setIsPlaying(true)}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      aria-label="Masaraddi Neuro Care Center Hero Introduction"
    >
      {/* Background Slideshow Layer */}
      <div className="absolute inset-0 z-0 overflow-hidden">
        {slides.map((slide, index) => {
          const isActive = index === currentIndex;
          return (
            <div
              key={slide.id}
              className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
                isActive ? 'opacity-100 z-10' : 'opacity-0 z-0 pointer-events-none'
              }`}
            >
              <img
                src={slide.url}
                alt={slide.altText}
                className={`w-full h-full object-cover object-center ${
                  isActive ? 'animate-ken-burns' : ''
                }`}
                loading={index === 0 ? 'eager' : 'lazy'}
              />
            </div>
          );
        })}

        {/* Precision Multi-layer Gradient Mesh for Superior Readability */}
        <div className="absolute inset-0 z-20 bg-gradient-to-r from-[#080E1A] via-[#080E1A]/90 to-[#080E1A]/70" />
        <div className="absolute inset-0 z-20 bg-gradient-to-t from-[#080E1A] via-transparent to-[#080E1A]/80" />
        <div className="absolute inset-0 z-20 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-sky-900/20 via-transparent to-transparent pointer-events-none" />
      </div>

      {/* Hero Content Layer */}
      <div className="relative z-30 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full py-12 md:py-24">
        <div className="max-w-3xl space-y-7">
          
          {/* Trust & Verified Google Rating Pill */}
          <div className="inline-flex flex-wrap items-center gap-2.5 px-4 py-2 rounded-full bg-slate-900/80 border border-sky-500/30 backdrop-blur-xl shadow-lg shadow-black/20">
            <div className="flex items-center text-amber-400 gap-1 text-xs sm:text-sm font-extrabold">
              <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
              <span>{hospitalConfig.rating}</span>
            </div>
            <span className="text-slate-600 text-xs">·</span>
            <span className="text-white text-xs font-semibold tracking-wide">
              {hospitalConfig.reviewCount} Verified Google Reviews
            </span>
            <span className="text-slate-600 text-xs hidden sm:inline">|</span>
            <div className="hidden sm:flex items-center gap-1.5 text-sky-300 text-xs font-medium">
              <MapPin className="w-3.5 h-3.5 text-sky-400" />
              <span>Station Road, Bagalkot</span>
            </div>
          </div>

          {/* Main H1 Headline with High-End Gradient Accents */}
          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold text-white tracking-tight leading-[1.12] font-outfit">
            Advanced Neurological Care. <br />
            <span className="neuro-gradient-text">Trusted Clinical Precision.</span>
          </h1>

          {/* Supporting Trust Copy */}
          <p className="text-base sm:text-lg md:text-xl text-slate-200/90 font-normal leading-relaxed max-w-2xl">
            {hospitalConfig.supportingText}
          </p>

          {/* Primary Action Buttons (Smooth gradient, refined borders, micro-interactions) */}
          <div className="pt-2 flex flex-wrap items-center gap-3 sm:gap-4">
            {/* Primary Call CTA */}
            <a
              href={`tel:${hospitalConfig.contact.phone}`}
              className="inline-flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-2xl bg-gradient-to-r from-sky-500 via-sky-600 to-blue-600 hover:from-sky-400 hover:to-blue-500 text-white font-bold text-sm sm:text-base shadow-xl shadow-sky-600/30 hover:shadow-sky-500/50 hover:scale-[1.02] active:scale-95 transition-all duration-200 border border-sky-300/30"
              aria-label="Call Masaraddi Neuro Care Center"
            >
              <Phone className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
              <span>Call Hospital Desk</span>
            </a>

            {/* Secondary WhatsApp CTA */}
            <a
              href={`https://wa.me/${hospitalConfig.contact.whatsappNumber}?text=${encodeURIComponent(
                hospitalConfig.contact.whatsappMessage
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2.5 px-5 py-3.5 rounded-2xl bg-slate-900/80 hover:bg-slate-800 text-slate-100 font-bold text-sm sm:text-base border border-slate-700/80 backdrop-blur-md shadow-md hover:scale-[1.02] active:scale-95 transition-all duration-200"
              aria-label="WhatsApp Masaraddi Neuro Care Center"
            >
              <MessageSquare className="w-4 h-4 sm:w-5 sm:h-5 text-emerald-400" />
              <span>WhatsApp Us</span>
            </a>

            {/* AI Assistant Quick Trigger */}
            <button
              onClick={onOpenAI}
              className="inline-flex items-center justify-center gap-2 px-4 py-3.5 rounded-2xl bg-sky-950/40 hover:bg-sky-900/50 text-sky-200 hover:text-white font-semibold text-xs sm:text-sm border border-sky-500/40 backdrop-blur-md transition-all duration-200 active:scale-95 hover:shadow-lg hover:shadow-sky-900/30"
              aria-label="Ask AI Assistant about Masaraddi Neuro Care Center"
            >
              <Sparkles className="w-4 h-4 text-sky-400 animate-pulse" />
              <span>Ask AI Assistant</span>
            </button>
          </div>

          {/* Quick Key Highlights Strip */}
          <div className="pt-6 grid grid-cols-2 sm:grid-cols-3 gap-3 border-t border-slate-800/80 max-w-2xl">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-sky-400 shrink-0" />
              <span className="text-xs text-slate-300 font-medium">Specialized Neuro Center</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-sky-400 shrink-0" />
              <span className="text-xs text-slate-300 font-medium">OPD & Inpatient Care</span>
            </div>
            <div className="flex items-center gap-2 col-span-2 sm:col-span-1">
              <CheckCircle2 className="w-4 h-4 text-sky-400 shrink-0" />
              <span className="text-xs text-slate-300 font-medium">Station Road, Bagalkot</span>
            </div>
          </div>

        </div>
      </div>

      {/* Slide Navigation Controls & Real Photo Tag Indicator */}
      <div className="absolute bottom-6 left-0 right-0 z-30 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-wrap items-center justify-between gap-4">
        {/* Current Photograph Area Tag */}
        <div className="hidden sm:flex items-center gap-2.5 px-3.5 py-1.5 rounded-xl bg-slate-900/80 backdrop-blur-md border border-slate-800 text-xs text-slate-300">
          <span className="w-2 h-2 rounded-full bg-sky-400 animate-pulse" />
          <span className="font-medium text-slate-400">Campus Facility:</span>
          <span className="text-white font-semibold">{slides[currentIndex].tag}</span>
        </div>

        {/* Slide Indicators & Controls */}
        <div className="flex items-center gap-3 bg-slate-900/80 backdrop-blur-xl px-4 py-2 rounded-full border border-slate-800 ml-auto shadow-xl">
          {/* Prev Slide Button */}
          <button
            onClick={prevSlide}
            className="p-1 rounded-full text-slate-300 hover:text-white hover:bg-white/10 transition-colors"
            aria-label="Previous hospital photo"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          {/* Dots */}
          <div className="flex items-center gap-1.5" role="tablist" aria-label="Slideshow pagination">
            {slides.map((slide, idx) => (
              <button
                key={slide.id}
                onClick={() => goToSlide(idx)}
                className={`transition-all duration-300 rounded-full ${
                  idx === currentIndex
                    ? 'w-6 h-2 bg-gradient-to-r from-sky-400 to-blue-500'
                    : 'w-2 h-2 bg-slate-700 hover:bg-slate-500'
                }`}
                aria-label={`Go to slide ${idx + 1}: ${slide.tag}`}
                aria-selected={idx === currentIndex}
                role="tab"
              />
            ))}
          </div>

          {/* Next Slide Button */}
          <button
            onClick={nextSlide}
            className="p-1 rounded-full text-slate-300 hover:text-white hover:bg-white/10 transition-colors"
            aria-label="Next hospital photo"
          >
            <ChevronRight className="w-4 h-4" />
          </button>

          {/* Play / Pause Toggle */}
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="p-1 rounded-full text-slate-300 hover:text-white hover:bg-white/10 transition-colors ml-1"
            aria-label={isPlaying ? 'Pause slideshow' : 'Play slideshow'}
          >
            {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>
    </section>
  );
};
