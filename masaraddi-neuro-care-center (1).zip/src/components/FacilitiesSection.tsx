import React, { useState } from 'react';
import { 
  Building, 
  Activity, 
  BedDouble, 
  Pill, 
  Sparkles, 
  ShieldCheck, 
  CheckCircle2, 
  Phone,
  Clock,
  Layers
} from 'lucide-react';
import { hospitalConfig } from '../config/hospitalConfig';

export const FacilitiesSection: React.FC = () => {
  const [activeTab, setActiveTab] = useState<number>(0);
  const facilities = hospitalConfig.facilities;
  const currentFacility = facilities[activeTab];

  return (
    <section id="facilities" className="py-24 bg-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-sky-50 border border-sky-200 text-sky-800 text-xs font-bold tracking-wide uppercase shadow-sm">
            <Building className="w-3.5 h-3.5 text-sky-600" />
            <span>Hospital Infrastructure & Wards</span>
          </div>
          
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#0B132B] tracking-tight font-outfit">
            Modern Clinical Facilities & Inpatient Amenities
          </h2>
          
          <p className="text-base sm:text-lg text-slate-600 leading-relaxed">
            Designed for patient comfort, rapid neurological response, and continuous medical observation in Bagalkot.
          </p>
        </div>

        {/* Facility Category Tabs */}
        <div className="mt-12 flex flex-wrap items-center justify-center gap-2 max-w-4xl mx-auto">
          {facilities.map((fac, idx) => (
            <button
              key={fac.id}
              onClick={() => setActiveTab(idx)}
              className={`px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold transition-all duration-200 ${
                activeTab === idx
                  ? 'bg-gradient-to-r from-sky-500 to-blue-600 text-white shadow-md shadow-sky-600/30 scale-[1.02]'
                  : 'bg-slate-100/90 hover:bg-slate-200 text-slate-600'
              }`}
            >
              {fac.title}
            </button>
          ))}
        </div>

        {/* Active Facility Spotlight Showcase */}
        <div className="mt-12 bg-[#F8FAFC] rounded-3xl p-6 sm:p-10 border border-slate-200/80 shadow-lg shadow-black/5">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            {/* Left: Real Facility Photograph */}
            <div className="lg:col-span-6 relative rounded-2xl overflow-hidden shadow-md group border border-slate-200 bg-slate-900 aspect-4/3">
              <img
                src={currentFacility.image}
                alt={currentFacility.altText || currentFacility.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
              
              <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between text-white text-xs">
                <span className="font-semibold bg-black/50 backdrop-blur-md px-3 py-1 rounded-full border border-white/20">
                  {currentFacility.category}
                </span>
                <span className="text-slate-300">Bagalkot Campus</span>
              </div>
            </div>

            {/* Right: Facility Details & Clinical Features */}
            <div className="lg:col-span-6 space-y-6">
              <div>
                <span className="text-xs font-bold text-sky-600 uppercase tracking-wider">
                  {currentFacility.category}
                </span>
                <h3 className="text-2xl sm:text-3xl font-bold text-[#0B132B] font-outfit mt-1">
                  {currentFacility.title}
                </h3>
                <p className="text-slate-600 text-sm sm:text-base mt-2 leading-relaxed">
                  {currentFacility.description}
                </p>
              </div>

              {/* Feature Points */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold text-[#0B132B] uppercase tracking-wider">
                  Facility Specifications & Capabilities:
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {currentFacility.features.map((feat, i) => (
                    <div key={i} className="flex items-center gap-2 p-2.5 rounded-xl bg-white border border-slate-200/80 shadow-xs">
                      <CheckCircle2 className="w-4 h-4 text-sky-600 shrink-0" />
                      <span className="text-xs font-semibold text-slate-700">{feat}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Admission / Inpatient Note */}
              <div className="pt-2 flex flex-wrap items-center gap-3">
                <a
                  href={`tel:${hospitalConfig.contact.phone}`}
                  className="inline-flex items-center gap-2 py-3 px-5 rounded-xl bg-[#0B132B] hover:bg-slate-900 text-white font-bold text-xs shadow-md transition-all hover:scale-[1.01]"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>Inquire About Admission / Bed Availability</span>
                </a>
              </div>
            </div>

          </div>
        </div>

        {/* Quick Facility Highlights Grid */}
        <div className="mt-12 grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-sm text-center space-y-2">
            <BedDouble className="w-6 h-6 text-sky-600 mx-auto" />
            <h4 className="text-xs sm:text-sm font-bold text-[#0B132B]">Inpatient Wards</h4>
            <p className="text-[11px] text-slate-500">General & Private Rooms</p>
          </div>
          <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-sm text-center space-y-2">
            <Activity className="w-6 h-6 text-teal-600 mx-auto" />
            <h4 className="text-xs sm:text-sm font-bold text-[#0B132B]">Neuro Diagnostics</h4>
            <p className="text-[11px] text-slate-500">EEG & Clinical Assessments</p>
          </div>
          <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-sm text-center space-y-2">
            <Pill className="w-6 h-6 text-indigo-600 mx-auto" />
            <h4 className="text-xs sm:text-sm font-bold text-[#0B132B]">Pharmacy Desk</h4>
            <p className="text-[11px] text-slate-500">Essential Neuro Medicines</p>
          </div>
          <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-sm text-center space-y-2">
            <Clock className="w-6 h-6 text-amber-600 mx-auto" />
            <h4 className="text-xs sm:text-sm font-bold text-[#0B132B]">Nursing Round</h4>
            <p className="text-[11px] text-slate-500">Continuous Monitoring</p>
          </div>
        </div>

      </div>
    </section>
  );
};
